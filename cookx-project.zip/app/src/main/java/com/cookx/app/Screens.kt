package com.cookx.app

import android.content.Intent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.background
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.util.Locale

val MEALS = listOf("Desayuno", "Almuerzo", "Cena", "Merienda")

@Composable
fun Title(text: String, ink: Color) =
    Text(text, fontSize = 20.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Serif, color = ink)

// ---------------------------------------------------------------- PLAN

@Composable
fun PickRecipeDialog(recipes: List<RecipeEntity>, ink: Color, onClose: () -> Unit, onPick: (RecipeEntity) -> Unit) {
    Dialog(onDismissRequest = onClose) {
        GlassCard(Modifier.fillMaxWidth().heightIn(max = 520.dp), solid = true) {
            Title("Elige una receta", ink)
            if (recipes.isEmpty()) Text("Primero crea una receta en la pestaña Recetas.", color = ink)
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(top = 8.dp)) {
                items(recipes, key = { it.id }) { r ->
                    GlassButton(r.name, ink, Modifier.fillMaxWidth()) { onPick(r) }
                }
            }
        }
    }
}

@Composable
fun PlanScreen(recipes: List<RecipeEntity>, plan: List<PlanEntry>, ink: Color, dao: CookDao, scope: CoroutineScope) {
    val today = remember { LocalDate.now() }
    var sel by remember { mutableIntStateOf(0) }
    var pickFor by remember { mutableStateOf<String?>(null) }
    val day = today.plusDays(sel.toLong()).toString()
    val week = (0..6).map { today.plusDays(it.toLong()).toString() }
    val weekEntries = plan.filter { it.date in week }
    val weekCost = weekEntries.sumOf { e -> recipes.find { it.id == e.recipeId }?.cost ?: 0.0 }

    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 12.dp)) {
        item {
            LazyRow {
                items((0..6).toList()) { n ->
                    val d = today.plusDays(n.toLong())
                    val nm = d.dayOfWeek.getDisplayName(java.time.format.TextStyle.SHORT, Locale("es"))
                    GlassChip("$nm ${d.dayOfMonth}", n == sel, ink) { sel = n }
                }
            }
        }
        item {
            GlassCard(Modifier.fillMaxWidth()) {
                Title("Resumen de la semana", ink)
                Text("${weekEntries.size} comidas programadas", color = ink)
                Text("Presupuesto estimado: ${"%.2f".format(weekCost)}", color = ink.copy(alpha = 0.8f))
                Spacer(Modifier.height(8.dp))
                GlassButton("Repetir este día la próxima semana", ink, small = true) {
                    val next = today.plusDays(sel.toLong() + 7).toString()
                    scope.launch { plan.filter { it.date == day }.forEach { dao.insertPlan(PlanEntry(date = next, meal = it.meal, recipeId = it.recipeId)) } }
                }
            }
        }
        items(MEALS) { meal ->
            GlassCard(Modifier.fillMaxWidth()) {
                Title(meal, ink)
                plan.filter { it.date == day && it.meal == meal }.forEach { e ->
                    Row(Modifier.padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(recipes.find { it.id == e.recipeId }?.name ?: "Receta eliminada", color = ink, modifier = Modifier.weight(1f))
                        GlassButton("Quitar", ink, small = true) { scope.launch { dao.deletePlan(e) } }
                    }
                }
                Spacer(Modifier.height(8.dp))
                GlassButton("+ Asignar receta", ink, small = true, accent = true) { pickFor = meal }
            }
        }
        item {
            val past = plan.filter { it.date < week.first() }.sortedByDescending { it.date }.take(10)
            GlassCard(Modifier.fillMaxWidth()) {
                Title("Historial de comidas", ink)
                if (past.isEmpty()) Text("Aquí verás las comidas de días anteriores.", color = ink.copy(alpha = 0.7f))
                past.forEach { e ->
                    Text("${e.date} · ${e.meal} · ${recipes.find { it.id == e.recipeId }?.name ?: "Receta eliminada"}", color = ink, fontSize = 14.sp)
                }
            }
        }
    }
    pickFor?.let { meal ->
        PickRecipeDialog(recipes, ink, { pickFor = null }) { r ->
            scope.launch { dao.insertPlan(PlanEntry(date = day, meal = meal, recipeId = r.id)) }
            pickFor = null
        }
    }
}

// ---------------------------------------------------------------- COMPRAS

@Composable
fun ShoppingScreen(lists: List<ShopList>, items: List<ShopItem>, ink: Color, dao: CookDao, scope: CoroutineScope) {
    val ctx = LocalContext.current
    var sel by remember { mutableStateOf<Long?>(null) }
    val cur = lists.find { it.id == sel } ?: lists.firstOrNull()
    var newList by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var qty by remember { mutableStateOf("") }
    var cat by remember { mutableStateOf("General") }
    val mine = items.filter { it.listId == cur?.id }

    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 12.dp)) {
        item {
            LazyRow { items(lists, key = { it.id }) { l -> GlassChip(l.name, l.id == cur?.id, ink) { sel = l.id } } }
            Row(verticalAlignment = Alignment.CenterVertically) {
                GlassField(newList, { newList = it }, "Nueva lista", ink, Modifier.weight(1f), singleLine = true)
                Spacer(Modifier.width(8.dp))
                GlassButton("Crear", ink, accent = true, small = true) {
                    if (newList.isNotBlank()) { val nm = newList.trim(); scope.launch { sel = dao.insertList(ShopList(name = nm)) }; newList = "" }
                }
            }
        }
        if (cur == null) {
            item { GlassCard(Modifier.fillMaxWidth()) { Text("Crea tu primera lista de compras arriba.", color = ink) } }
        } else {
            item {
                GlassCard(Modifier.fillMaxWidth()) {
                    Title(cur.name, ink)
                    Text("${mine.count { !it.checked }} pendientes · ${mine.count { it.checked }} comprados", color = ink.copy(alpha = 0.7f), fontSize = 13.sp)
                    GlassField(name, { name = it }, "Producto", ink, Modifier.fillMaxWidth(), singleLine = true)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        GlassField(qty, { qty = it }, "Cantidad", ink, Modifier.weight(1f), singleLine = true)
                        GlassField(cat, { cat = it }, "Categoría", ink, Modifier.weight(1f), singleLine = true)
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        GlassButton("Añadir", ink, Modifier.weight(1f), accent = true, small = true) {
                            if (name.isNotBlank()) {
                                scope.launch { dao.insertItem(ShopItem(listId = cur.id, name = name.trim(), qty = qty.trim(), category = cat.trim().ifBlank { "General" })) }
                                name = ""; qty = ""
                            }
                        }
                        GlassButton("Compartir", ink, Modifier.weight(1f), small = true) {
                            val text = cur.name + "\n" + mine.joinToString("\n") {
                                (if (it.checked) "✓ " else "• ") + it.name + if (it.qty.isNotBlank()) " (${it.qty})" else ""
                            }
                            val send = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text) }
                            ctx.startActivity(Intent.createChooser(send, "Compartir lista").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        }
                        GlassButton("Borrar lista", ink, Modifier.weight(1f), small = true) {
                            scope.launch { dao.deleteItemsOf(cur.id); dao.deleteList(cur) }; sel = null
                        }
                    }
                }
            }
            mine.groupBy { it.category }.forEach { (category, group) ->
                item(key = "cat-$category") {
                    GlassCard(Modifier.fillMaxWidth()) {
                        Text(category, color = Accent, fontWeight = FontWeight.Bold)
                        group.forEach { it0 ->
                            Row(Modifier.padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                                val emo = remember(it0.name, it0.category) { ingredientEmoji(it0.name, categoryEmoji(it0.category)) }
                                FoodBadge(emo, 42.dp, it0.checked)
                                Spacer(Modifier.width(12.dp))
                                Text(
                                    it0.name + if (it0.qty.isNotBlank()) " · ${it0.qty}" else "",
                                    color = ink.copy(alpha = if (it0.checked) 0.5f else 1f),
                                    textDecoration = if (it0.checked) TextDecoration.LineThrough else null,
                                    modifier = Modifier.weight(1f).liquidClick { scope.launch { dao.updateItem(it0.copy(checked = !it0.checked)) } }.padding(vertical = 6.dp)
                                )
                                GlassButton("✕", ink, small = true) { scope.launch { dao.deleteItem(it0) } }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- DATOS

@Composable
fun StatCard(value: String, label: String, ink: Color, modifier: Modifier = Modifier) {
    GlassCard(modifier) {
        Text(value, fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Accent)
        Text(label, fontSize = 12.sp, color = ink.copy(alpha = 0.75f))
    }
}

@Composable
fun StatsScreen(recipes: List<RecipeEntity>, plan: List<PlanEntry>, ink: Color) {
    val unit = Regex("^(\\d+(?:[.,]\\d+)?\\s*)?(kg|g|ml|l|tazas?|cucharadas?|cucharaditas?|unidades?)?\\s*(de\\s+)?")
    val top = recipes.flatMap { it.ingredients.lines() }
        .map { unit.replaceFirst(it.trim().lowercase(), "").trim() }
        .filter { it.isNotBlank() }
        .groupingBy { it }.eachCount().entries.sortedByDescending { it.value }.take(5)
    val byCat = recipes.groupingBy { it.category }.eachCount().entries.sortedByDescending { it.value }.take(5)
    val minutes = recipes.sumOf { it.cookedMinutes }
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("${recipes.size}", "Recetas creadas", ink, Modifier.weight(1f))
            StatCard("${recipes.count { it.favorite }}", "Favoritas", ink, Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("${recipes.sumOf { it.cooked }}", "Preparaciones", ink, Modifier.weight(1f))
            StatCard("${minutes / 60} h ${minutes % 60} min", "Tiempo cocinando*", ink, Modifier.weight(1f))
        }
        GlassCard(Modifier.fillMaxWidth()) {
            Title("Recetas por categoría", ink)
            if (byCat.isEmpty()) Text("Crea recetas para ver esta gráfica.", color = ink.copy(alpha = 0.7f))
            val max = (byCat.maxOfOrNull { it.value } ?: 1).toFloat()
            byCat.forEach { (k, v) -> BarRow(k, v, v / max, ink) }
        }
        GlassCard(Modifier.fillMaxWidth()) {
            Title("Ingredientes más utilizados", ink)
            if (top.isEmpty()) Text("Se calcula con los ingredientes de tus recetas.", color = ink.copy(alpha = 0.7f))
            val max = (top.maxOfOrNull { it.value } ?: 1).toFloat()
            top.forEach { (k, v) -> BarRow(k, v, v / max, ink) }
        }
        Text("*Suma el tiempo de cada receta que marcas como preparada. Comidas planificadas: ${plan.size}.", fontSize = 11.sp, color = ink.copy(alpha = 0.6f))
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
fun BarRow(label: String, value: Int, fraction: Float, ink: Color) {
    Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = ink, fontSize = 13.sp, modifier = Modifier.width(110.dp), maxLines = 1)
        Box(Modifier.weight(1f).height(12.dp).clip(RoundedCornerShape(50)).background(Color.White.copy(alpha = 0.1f))) {
            Box(Modifier.fillMaxWidth(fraction.coerceIn(0.05f, 1f)).fillMaxHeight().background(Accent))
        }
        Text("  $value", color = ink, fontSize = 13.sp)
    }
}
