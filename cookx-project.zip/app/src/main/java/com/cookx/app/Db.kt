package com.cookx.app

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow
import org.json.JSONArray

@Entity(tableName = "recipes")
data class RecipeEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val category: String,
    val minutes: Int,
    val portions: Int,
    val ingredients: String,
    val steps: String,
    val tags: String = "",
    val notes: String = "",
    val photo: String = "",
    val cost: Double = 0.0,
    val favorite: Boolean = false,
    val cooked: Int = 0,
    val cookedMinutes: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "shop_lists")
data class ShopList(@PrimaryKey(autoGenerate = true) val id: Long = 0, val name: String)

@Entity(tableName = "shop_items")
data class ShopItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val listId: Long,
    val name: String,
    val qty: String = "",
    val category: String = "General",
    val checked: Boolean = false
)

@Entity(tableName = "plan_entries")
data class PlanEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val date: String,
    val meal: String,
    val recipeId: Long
)

@Dao
interface CookDao {
    @Query("SELECT * FROM recipes ORDER BY createdAt DESC") fun recipes(): Flow<List<RecipeEntity>>
    @Insert suspend fun insert(r: RecipeEntity): Long
    @Insert suspend fun insertRecipes(l: List<RecipeEntity>)
    @Update suspend fun update(r: RecipeEntity)
    @Delete suspend fun delete(r: RecipeEntity)

    @Query("SELECT * FROM shop_lists ORDER BY id") fun lists(): Flow<List<ShopList>>
    @Query("SELECT * FROM shop_lists ORDER BY id LIMIT 1") suspend fun firstList(): ShopList?
    @Insert suspend fun insertList(l: ShopList): Long
    @Delete suspend fun deleteList(l: ShopList)
    @Query("DELETE FROM shop_items WHERE listId = :id") suspend fun deleteItemsOf(id: Long)

    @Query("SELECT * FROM shop_items ORDER BY checked, id") fun items(): Flow<List<ShopItem>>
    @Insert suspend fun insertItem(i: ShopItem): Long
    @Update suspend fun updateItem(i: ShopItem)
    @Delete suspend fun deleteItem(i: ShopItem)

    @Query("SELECT * FROM plan_entries ORDER BY id") fun plan(): Flow<List<PlanEntry>>
    @Insert suspend fun insertPlan(p: PlanEntry): Long
    @Delete suspend fun deletePlan(p: PlanEntry)
}

@Database(
    entities = [RecipeEntity::class, ShopList::class, ShopItem::class, PlanEntry::class],
    version = 1,
    exportSchema = false
)
abstract class CookDb : RoomDatabase() {
    abstract fun dao(): CookDao

    companion object {
        @Volatile private var inst: CookDb? = null
        fun get(c: Context): CookDb = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(c.applicationContext, CookDb::class.java, "cookx.db").build().also { inst = it }
        }
    }
}

/** Pasa las recetas guardadas por la versión anterior (SharedPreferences) a Room, una sola vez. */
suspend fun migrateLegacy(ctx: Context, db: CookDb) {
    val p = ctx.getSharedPreferences("cookx", Context.MODE_PRIVATE)
    if (p.getBoolean("migrated", false)) return
    val raw = p.getString("recipes", null)
    if (raw != null) {
        val a = JSONArray(raw)
        val l = (0 until a.length()).map {
            val o = a.getJSONObject(it)
            RecipeEntity(
                name = o.getString("n"), category = o.getString("c"), minutes = o.getInt("t"),
                portions = o.getInt("p"), ingredients = o.getString("i"), steps = o.getString("s")
            )
        }
        if (l.isNotEmpty()) db.dao().insertRecipes(l)
    }
    p.edit().putBoolean("migrated", true).apply()
}
