package com.cookx.app

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.delay

val MASS = linkedMapOf("g" to 1.0, "kg" to 1000.0, "oz" to 28.349523125, "lb" to 453.59237)
val VOL = linkedMapOf(
    "ml" to 1.0, "l" to 1000.0, "taza (240 ml)" to 240.0, "cucharada (15 ml)" to 15.0,
    "cucharadita (5 ml)" to 5.0, "fl oz" to 29.5735295625
)
// Gramos aproximados por taza (240 ml); varían según la marca y cómo se llene la taza.
val GRAMS_PER_CUP = listOf(
    "Harina de trigo" to 120.0, "Azúcar blanca" to 200.0, "Mantequilla" to 227.0,
    "Arroz crudo" to 185.0, "Leche" to 240.0, "Miel" to 340.0
)
val TEMPS = listOf(
    "Agua hirviendo (nivel del mar)" to 100.0,
    "Aves: temperatura interna segura (USDA)" to 74.0,
    "Carne molida: interna segura (USDA)" to 71.0,
    "Res, cerdo, cordero enteros: interna segura (USDA)" to 63.0,
    "Pescado: interna segura (USDA)" to 63.0,
    "Horno suave" to 150.0, "Horno moderado" to 180.0, "Horno fuerte" to 220.0
)
val SUBS = listOf(
    Triple("1 taza de suero de leche", "1 taza de leche + 1 cucharada de jugo de limón o vinagre; reposar 5 minutos.", "Resultado similar en repostería; no sirve para beber."),
    Triple("1 cucharadita de polvo de hornear", "1/4 cucharadita de bicarbonato + 1/2 cucharadita de crémor tártaro.", "Úsalo de inmediato; no se almacena."),
    Triple("1 huevo (en repostería)", "1/4 taza de puré de manzana sin azúcar.", "Cambia la textura; no sirve para recetas donde el huevo es la base."),
    Triple("1 taza de azúcar moreno", "1 taza de azúcar blanca + 1 cucharada de melaza.", "El sabor es parecido, no idéntico."),
    Triple("1 taza de crema agria", "1 taza de yogur natural espeso.", "Puede cortarse a fuego alto."),
    Triple("1 taza de mantequilla", "7/8 de taza de aceite vegetal.", "Menos sabor; úsalo en bizcochos, no en masas hojaldradas.")
)

fun fmt(v: Double): String {
    val s = "%.3f".format(v).trimEnd('0').trimEnd('.')
    return if (s.isEmpty()) "0" else s
}

fun notifyTimer(ctx: Context, label: String) {
    val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel("timers", "Temporizadores", NotificationManager.IMPORTANCE_HIGH))
    val n = NotificationCompat.Builder(ctx, "timers")
        .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
        .setContentTitle("CookX")
        .setContentText("Temporizador terminado: $label")
        .setAutoCancel(true)
        .build()
    nm.notify(label.hashCode(), n)
}

class TimerItem(val label: String, val total: Long, val endAt: Long) { var notified by mutableStateOf(false) }

@Composable
fun ToolsScreen(ink: Color) {
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 12.dp)) {
        item { ConverterCard(ink) }
        item { PortionsCard(ink) }
        item { CupGramsCard(ink) }
        item { TempCard(ink) }
        item { SubsCard(ink) }
        item { TimersCard(ink) }
    }
}

@Composable
fun ConverterCard(ink: Color) {
    var kind by remember { mutableStateOf("Masa") }
    val units = if (kind == "Masa") MASS else VOL
    var from by remember(kind) { mutableStateOf(units.keys.first()) }
    var to by remember(kind) { mutableStateOf(units.keys.elementAt(1)) }
    var input by remember { mutableStateOf("1") }
    val v = input.replace(',', '.').toDoubleOrNull()
    GlassCard(Modifier.fillMaxWidth()) {
        Title("Conversor de unidades", ink)
        LazyRow { items(listOf("Masa", "Volumen")) { k -> GlassChip(k, k == kind, ink) { kind = k } } }
        GlassField(input, { input = it }, "Cantidad", ink, Modifier.fillMaxWidth(), singleLine = true, decimal = true)
        Text("De", color = ink.copy(alpha = 0.7f), fontSize = 12.sp)
        LazyRow { items(units.keys.toList()) { u -> GlassChip(u, u == from, ink) { from = u } } }
        Text("A", color = ink.copy(alpha = 0.7f), fontSize = 12.sp)
        LazyRow { items(units.keys.toList()) { u -> GlassChip(u, u == to, ink) { to = u } } }
        Spacer(Modifier.height(6.dp))
        Text(
            if (v == null) "Escribe un número" else "${fmt(v)} $from = ${fmt(v * units.getValue(from) / units.getValue(to))} $to",
            color = Accent, fontSize = 18.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
        )
    }
}

@Composable
fun PortionsCard(ink: Color) {
    var lines by remember { mutableStateOf("") }
    var from by remember { mutableStateOf("4") }
    var to by remember { mutableStateOf("6") }
    val f = (to.toDoubleOrNull() ?: 0.0) / (from.toDoubleOrNull()?.takeIf { it > 0 } ?: 1.0)
    GlassCard(Modifier.fillMaxWidth()) {
        Title("Calculadora de porciones", ink)
        GlassField(lines, { lines = it }, "Ingredientes (uno por línea, ej: 200 g harina)", ink, Modifier.fillMaxWidth(), minLines = 3)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GlassField(from, { from = it }, "Porciones originales", ink, Modifier.weight(1f), singleLine = true, number = true)
            GlassField(to, { to = it }, "Porciones deseadas", ink, Modifier.weight(1f), singleLine = true, number = true)
        }
        lines.lines().filter { it.isNotBlank() }.forEach { Text("• " + scale(it, f), color = Accent) }
    }
}

@Composable
fun CupGramsCard(ink: Color) {
    var cups by remember { mutableStateOf("1") }
    val c = cups.replace(',', '.').toDoubleOrNull()
    GlassCard(Modifier.fillMaxWidth()) {
        Title("Equivalencias de ingredientes", ink)
        GlassField(cups, { cups = it }, "Tazas (240 ml)", ink, Modifier.fillMaxWidth(), singleLine = true, decimal = true)
        GRAMS_PER_CUP.forEach { (n, g) -> Text(if (c == null) n else "$n: ${fmt(c * g)} g", color = ink) }
        Text("Valores aproximados; varían según el ingrediente y la marca.", fontSize = 11.sp, color = ink.copy(alpha = 0.6f))
    }
}

@Composable
fun TempCard(ink: Color) {
    var c by remember { mutableStateOf("180") }
    val v = c.replace(',', '.').toDoubleOrNull()
    GlassCard(Modifier.fillMaxWidth()) {
        Title("Temperaturas de cocción", ink)
        GlassField(c, { c = it }, "Grados Celsius", ink, Modifier.fillMaxWidth(), singleLine = true, decimal = true)
        if (v != null) Text("${fmt(v)} °C = ${fmt(v * 9 / 5 + 32)} °F", color = Accent, fontSize = 18.sp)
        Spacer(Modifier.height(6.dp))
        TEMPS.forEach { (n, t) -> Text("$n: ${fmt(t)} °C / ${fmt(t * 9 / 5 + 32)} °F", color = ink, fontSize = 14.sp) }
    }
}

@Composable
fun SubsCard(ink: Color) {
    GlassCard(Modifier.fillMaxWidth()) {
        Title("Sustituciones de ingredientes", ink)
        SUBS.forEach { (a, b, w) ->
            Text(a, color = Accent, modifier = Modifier.padding(top = 8.dp))
            Text(b, color = ink)
            Text("Aviso: $w", color = ink.copy(alpha = 0.65f), fontSize = 12.sp)
        }
        Text("Equivalencias culinarias de uso común. Revisa alérgenos si cocinas para otras personas.", fontSize = 11.sp, color = ink.copy(alpha = 0.6f), modifier = Modifier.padding(top = 8.dp))
    }
}

@Composable
fun TimersCard(ink: Color) {
    val ctx = LocalContext.current
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    val timers = remember { mutableStateListOf<TimerItem>() }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var label by remember { mutableStateOf("") }
    var mins by remember { mutableStateOf("10") }
    LaunchedEffect(Unit) { while (true) { delay(500); now = System.currentTimeMillis() } }
    LaunchedEffect(now) {
        timers.forEach { if (now >= it.endAt && !it.notified) { it.notified = true; notifyTimer(ctx, it.label) } }
    }
    GlassCard(Modifier.fillMaxWidth()) {
        Title("Temporizadores", ink)
        GlassField(label, { label = it }, "Nombre (ej: pasta)", ink, Modifier.fillMaxWidth(), singleLine = true)
        GlassField(mins, { mins = it }, "Minutos", ink, Modifier.fillMaxWidth(), singleLine = true, decimal = true)
        Spacer(Modifier.height(8.dp))
        GlassButton("Iniciar temporizador", ink, Modifier.fillMaxWidth(), accent = true) {
            val m = mins.replace(',', '.').toDoubleOrNull()
            if (m != null && m > 0) {
                if (Build.VERSION.SDK_INT >= 33) perm.launch(Manifest.permission.POST_NOTIFICATIONS)
                val total = (m * 60000).toLong()
                timers.add(TimerItem(label.trim().ifBlank { "Temporizador" }, total, System.currentTimeMillis() + total))
                label = ""
            }
        }
        timers.forEach { t ->
            val left = (t.endAt - now).coerceAtLeast(0)
            val s = left / 1000
            Column(Modifier.padding(top = 12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(t.label, color = ink, modifier = Modifier.weight(1f))
                    Text(if (left == 0L) "¡Listo!" else "%02d:%02d".format(s / 60, s % 60), color = Accent, fontSize = 20.sp)
                    Spacer(Modifier.width(8.dp))
                    GlassButton("✕", ink, small = true) { timers.remove(t) }
                }
                Box(Modifier.fillMaxWidth().height(10.dp).padding(top = 4.dp).clip(RoundedCornerShape(50)).background(Color.White.copy(alpha = 0.12f))) {
                    Box(Modifier.fillMaxWidth(1f - left.toFloat() / t.total).fillMaxHeight().background(Accent))
                }
            }
        }
        Text("Los temporizadores funcionan mientras la app esté abierta o en segundo plano reciente.", fontSize = 11.sp, color = ink.copy(alpha = 0.6f), modifier = Modifier.padding(top = 8.dp))
    }
}
