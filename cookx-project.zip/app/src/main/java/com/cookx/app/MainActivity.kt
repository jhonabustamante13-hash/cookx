@file:OptIn(ExperimentalMaterial3Api::class)

package com.cookx.app

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import org.json.JSONArray
import org.json.JSONObject

val CATS = listOf(
    "Desayunos", "Almuerzos", "Cenas", "Meriendas", "Postres", "Bebidas", "Sopas", "Ensaladas", "Pastas",
    "Arroces", "Carnes", "Pollo", "Pescados", "Mariscos", "Vegetariana", "Vegana", "Panadería", "Repostería",
    "Comida rápida", "Comida internacional", "Comida tradicional", "Salsas", "Aperitivos", "Guarniciones",
    "Comidas saludables"
)
val TABS = listOf("Recetas" to "🍳", "Plan" to "📅", "Compras" to "🛒", "Útiles" to "⏱", "Datos" to "📊")

data class Recipe(val name: String, val category: String, val minutes: Int, val portions: Int, val ingredients: String, val steps: String)

class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("cookx", Context.MODE_PRIVATE)
    fun load(): List<Recipe> {
        val a = JSONArray(p.getString("recipes", "[]"))
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Recipe(o.getString("n"), o.getString("c"), o.getInt("t"), o.getInt("p"), o.getString("i"), o.getString("s"))
        }
    }
    fun save(l: List<Recipe>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("n", it.name).put("c", it.category).put("t", it.minutes).put("p", it.portions).put("i", it.ingredients).put("s", it.steps)) }
        p.edit().putString("recipes", a.toString()).apply()
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { CookXApp() }
    }
}

@Composable
fun CookXApp() {
    val dark = isSystemInDarkTheme()
    val ink = if (dark) Color(0xFFF7EADC) else Color(0xFF2B1D14)
    val ctx = LocalContext.current
    val store = remember { Store(ctx) }
    val recipes = remember { mutableStateListOf<Recipe>().apply { addAll(store.load()) } }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var creating by remember { mutableStateOf(false) }
    MaterialTheme(colorScheme = if (dark) darkColorScheme(primary = Accent) else lightColorScheme(primary = Accent)) {
        LiquidBackground {
            Column(Modifier.fillMaxSize().systemBarsPadding()) {
                Row(Modifier.fillMaxWidth().padding(16.dp, 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("CookX", fontSize = 30.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Serif, color = ink)
                    Spacer(Modifier.weight(1f))
                    if (tab == 0) Button(onClick = { creating = true }) { Text("+ Nueva receta") }
                }
                Box(Modifier.weight(1f)) {
                    AnimatedContent(
                        targetState = tab,
                        transitionSpec = { (fadeIn() + scaleIn(initialScale = 0.92f)) togetherWith fadeOut() },
                        label = "tab"
                    ) { t ->
                        if (t == 0) RecipesScreen(recipes, ink) { recipes.remove(it); store.save(recipes) }
                        else Placeholder(TABS[t].first, ink)
                    }
                }
                GlassNav(tab, ink) { tab = it }
            }
            if (creating) NewRecipeDialog(ink, { creating = false }) {
                recipes.add(0, it); store.save(recipes); creating = false
            }
        }
    }
}

@Composable
fun GlassNav(sel: Int, ink: Color, onSel: (Int) -> Unit) {
    val shape = RoundedCornerShape(32.dp)
    BoxWithConstraints(
        Modifier.padding(16.dp, 8.dp).fillMaxWidth().height(64.dp).clip(shape)
            .background(Color.White.copy(alpha = 0.28f)).border(1.dp, Color.White.copy(alpha = 0.6f), shape)
    ) {
        val w = maxWidth / TABS.size
        val x by animateDpAsState(w * sel, spring(dampingRatio = 0.5f, stiffness = 260f), label = "pill")
        Box(Modifier.offset(x = x).width(w).fillMaxHeight().padding(5.dp).clip(RoundedCornerShape(27.dp)).background(Color.White.copy(alpha = 0.45f)))
        Row(Modifier.fillMaxSize()) {
            TABS.forEachIndexed { i, (name, emoji) ->
                Column(
                    Modifier.weight(1f).fillMaxHeight().clickable { onSel(i) },
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(emoji, fontSize = 20.sp)
                    Text(name, fontSize = 11.sp, color = if (i == sel) Accent else ink.copy(alpha = 0.7f))
                }
            }
        }
    }
}

@Composable
fun Placeholder(name: String, ink: Color) {
    Box(Modifier.fillMaxSize().padding(16.dp)) {
        GlassCard(Modifier.fillMaxWidth()) {
            Text(name, fontSize = 22.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Serif, color = ink)
            Text("Esta sección llega en las siguientes fases.", color = ink.copy(alpha = 0.7f))
        }
    }
}

@Composable
fun RecipesScreen(recipes: List<Recipe>, ink: Color, onDelete: (Recipe) -> Unit) {
    var cat by remember { mutableStateOf("Todas") }
    var q by remember { mutableStateOf("") }
    val words = q.split(",").map { it.trim() }.filter { it.isNotEmpty() }
    val shown = recipes.filter { r ->
        (cat == "Todas" || r.category == cat) &&
            (words.isEmpty() || words.any { r.name.contains(it, true) || r.ingredients.contains(it, true) })
    }
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), placeholder = { Text("Buscar por nombre o ingredientes") }, singleLine = true, shape = RoundedCornerShape(50))
        LazyRow(Modifier.padding(vertical = 8.dp)) {
            items(listOf("Todas") + CATS) { c ->
                FilterChip(selected = c == cat, onClick = { cat = c }, label = { Text(c) }, modifier = Modifier.padding(end = 6.dp))
            }
        }
        if (shown.isEmpty()) {
            GlassCard(Modifier.fillMaxWidth()) {
                Text(
                    if (recipes.isEmpty()) "Aún no tienes recetas. Toca + Nueva receta para crear la primera." else "Sin resultados. Prueba con otro ingrediente.",
                    color = ink
                )
            }
        }
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(shown) { RecipeCard(it, ink, onDelete) }
        }
    }
}

fun scale(line: String, f: Double): String {
    val m = Regex("^\\s*(\\d+(?:[.,]\\d+)?)(.*)\$").find(line) ?: return line
    val n = m.groupValues[1].replace(',', '.').toDouble() * f
    return (if (n % 1.0 == 0.0) n.toInt().toString() else "%.1f".format(n)) + m.groupValues[2]
}

@Composable
fun RecipeCard(r: Recipe, ink: Color, onDelete: (Recipe) -> Unit) {
    var open by remember { mutableStateOf(false) }
    var servings by remember { mutableIntStateOf(r.portions) }
    GlassCard(Modifier.fillMaxWidth().animateContentSize(spring(dampingRatio = 0.6f, stiffness = 200f)).clickable { open = !open }) {
        Text(r.name, fontSize = 20.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Serif, color = ink)
        Text("${r.category} · ${r.minutes} min · ${r.portions} porciones", fontSize = 13.sp, color = ink.copy(alpha = 0.65f))
        if (open) {
            Row(Modifier.padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Porciones", color = ink, modifier = Modifier.weight(1f))
                TextButton({ if (servings > 1) servings-- }) { Text("−") }
                Text("$servings", color = ink, fontWeight = FontWeight.Bold)
                TextButton({ servings++ }) { Text("+") }
            }
            r.ingredients.lines().filter { it.isNotBlank() }.forEach {
                Text("• " + scale(it, servings.toDouble() / r.portions), color = ink)
            }
            Spacer(Modifier.height(8.dp))
            r.steps.lines().filter { it.isNotBlank() }.forEachIndexed { i, s -> StepRow(i + 1, s, ink) }
            TextButton({ onDelete(r) }) { Text("Eliminar") }
        }
    }
}

@Composable
fun StepRow(n: Int, text: String, ink: Color) {
    var done by remember { mutableStateOf(false) }
    Row(Modifier.fillMaxWidth().clickable { done = !done }.padding(vertical = 6.dp)) {
        Text("$n.", color = Accent, fontWeight = FontWeight.Bold, modifier = Modifier.width(28.dp))
        Text(
            text,
            color = ink.copy(alpha = if (done) 0.5f else 1f),
            textDecoration = if (done) TextDecoration.LineThrough else null
        )
    }
}

@Composable
fun NewRecipeDialog(ink: Color, onClose: () -> Unit, onSave: (Recipe) -> Unit) {
    var n by remember { mutableStateOf("") }
    var c by remember { mutableStateOf("Almuerzos") }
    var t by remember { mutableStateOf("30") }
    var p by remember { mutableStateOf("4") }
    var i by remember { mutableStateOf("") }
    var s by remember { mutableStateOf("") }
    Dialog(onDismissRequest = onClose) {
        GlassCard(Modifier.fillMaxWidth().heightIn(max = 640.dp).verticalScroll(rememberScrollState()), solid = true) {
            Text("Nueva receta", fontSize = 22.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Serif, color = ink)
            OutlinedTextField(n, { n = it }, Modifier.fillMaxWidth(), label = { Text("Nombre") }, singleLine = true)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(t, { t = it }, Modifier.weight(1f), label = { Text("Minutos") }, singleLine = true)
                OutlinedTextField(p, { p = it }, Modifier.weight(1f), label = { Text("Porciones") }, singleLine = true)
            }
            LazyRow(Modifier.padding(vertical = 8.dp)) {
                items(CATS) { k -> FilterChip(selected = k == c, onClick = { c = k }, label = { Text(k) }, modifier = Modifier.padding(end = 6.dp)) }
            }
            OutlinedTextField(i, { i = it }, Modifier.fillMaxWidth(), label = { Text("Ingredientes (uno por línea, ej: 2 huevos)") }, minLines = 3)
            OutlinedTextField(s, { s = it }, Modifier.fillMaxWidth(), label = { Text("Pasos (uno por línea)") }, minLines = 3)
            Spacer(Modifier.height(10.dp))
            Button(
                onClick = {
                    if (n.isNotBlank()) onSave(Recipe(n.trim(), c, t.toIntOrNull() ?: 0, (p.toIntOrNull() ?: 1).coerceAtLeast(1), i.trim(), s.trim()))
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Guardar receta") }
        }
    }
}
