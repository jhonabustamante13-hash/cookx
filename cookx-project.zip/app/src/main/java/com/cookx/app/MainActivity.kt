@file:OptIn(ExperimentalMaterial3Api::class)

package com.cookx.app

import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.launch
import java.io.File

val CATS = listOf(
    "Desayunos", "Almuerzos", "Cenas", "Meriendas", "Postres", "Bebidas", "Sopas", "Ensaladas", "Pastas",
    "Arroces", "Carnes", "Pollo", "Pescados", "Mariscos", "Vegetariana", "Vegana", "Panadería", "Repostería",
    "Comida rápida", "Comida internacional", "Comida tradicional", "Salsas", "Aperitivos", "Guarniciones",
    "Comidas saludables"
)
val TABS = listOf("Recetas", "Plan", "Compras", "Útiles", "Datos")
val INK = Color(0xFFF5F5F5)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { CookXApp() }
    }
}

class Actions(
    val fav: (RecipeEntity) -> Unit,
    val edit: (RecipeEntity) -> Unit,
    val delete: (RecipeEntity) -> Unit,
    val cooked: (RecipeEntity) -> Unit,
    val toList: (List<String>) -> Unit,
    val cook: (RecipeEntity) -> Unit
)

@Composable
fun CookXApp() {
    val ink = INK
    val ctx = LocalContext.current
    val db = remember { CookDb.get(ctx) }
    val dao = remember { db.dao() }
    val scope = rememberCoroutineScope()
    val recipes by dao.recipes().collectAsState(initial = emptyList())
    val lists by dao.lists().collectAsState(initial = emptyList())
    val items by dao.items().collectAsState(initial = emptyList())
    val plan by dao.plan().collectAsState(initial = emptyList())
    LaunchedEffect(Unit) { migrateLegacy(ctx, db) }

    var tab by rememberSaveable { mutableIntStateOf(0) }
    var creating by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<RecipeEntity?>(null) }
    var cooking by remember { mutableStateOf<RecipeEntity?>(null) }
    var toast by remember { mutableStateOf("") }

    val act = remember {
        Actions(
            fav = { r -> scope.launch { dao.update(r.copy(favorite = !r.favorite)) } },
            edit = { editing = it },
            delete = { r -> scope.launch { dao.delete(r) } },
            cooked = { r ->
                scope.launch { dao.update(r.copy(cooked = r.cooked + 1, cookedMinutes = r.cookedMinutes + r.minutes)) }
                toast = "Receta registrada como preparada"
            },
            toList = { lines ->
                scope.launch {
                    val id = dao.firstList()?.id ?: dao.insertList(ShopList(name = "Mi lista"))
                    lines.filter { it.isNotBlank() }.forEach { dao.insertItem(ShopItem(listId = id, name = it.trim())) }
                }
                toast = "Ingredientes añadidos a Compras"
            },
            cook = { cooking = it }
        )
    }
    LaunchedEffect(toast) {
        if (toast.isNotEmpty()) { kotlinx.coroutines.delay(2200); toast = "" }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Accent)) {
        GlassBackground {
            Column(Modifier.fillMaxSize().systemBarsPadding()) {
                Row(Modifier.fillMaxWidth().padding(16.dp, 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("CookX", fontSize = 30.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Serif, color = ink)
                    Spacer(Modifier.weight(1f))
                    if (tab == 0) GlassButton("+ Nueva receta", ink, accent = true) { creating = true }
                }
                Box(Modifier.weight(1f)) {
                    AnimatedContent(
                        targetState = tab,
                        transitionSpec = { (fadeIn() + scaleIn(initialScale = 0.92f)) togetherWith fadeOut() },
                        label = "tab"
                    ) { t ->
                        when (t) {
                            0 -> RecipesScreen(recipes, ink, act)
                            1 -> PlanScreen(recipes, plan, ink, dao, scope)
                            2 -> ShoppingScreen(lists, items, ink, dao, scope)
                            3 -> ToolsScreen(ink)
                            else -> StatsScreen(recipes, plan, ink)
                        }
                    }
                    if (toast.isNotEmpty()) {
                        GlassCard(Modifier.align(Alignment.BottomCenter).padding(16.dp)) { Text(toast, color = ink) }
                    }
                }
                GlassNav(tab, ink) { tab = it }
            }
            if (creating) RecipeDialog(null, ink, { creating = false }) {
                scope.launch { dao.insert(it) }; creating = false
            }
            editing?.let { e ->
                RecipeDialog(e, ink, { editing = null }) { scope.launch { dao.update(it) }; editing = null }
            }
            cooking?.let { CookMode(it, ink) { cooking = null } }
        }
    }
}

@Composable
fun GlassNav(sel: Int, ink: Color, onSel: (Int) -> Unit) {
    BoxWithConstraints(Modifier.padding(16.dp, 8.dp).fillMaxWidth().height(80.dp).glass(RoundedCornerShape(40.dp))) {
        val w = maxWidth / TABS.size
        val x by animateDpAsState(w * sel, spring(dampingRatio = 0.5f, stiffness = 260f), label = "pill")
        Box(Modifier.offset(x = x).width(w).fillMaxHeight().padding(6.dp).glass(RoundedCornerShape(34.dp), tint = Accent.copy(alpha = 0.35f)))
        Row(Modifier.fillMaxSize()) {
            TABS.forEachIndexed { i, name ->
                Column(
                    Modifier.weight(1f).fillMaxHeight().liquidClick { onSel(i) },
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Box(Modifier.size(38.dp).glass(CircleShape), contentAlignment = Alignment.Center) { GlassIcon(i, i == sel, ink) }
                    Text(name, fontSize = 10.sp, color = if (i == sel) Accent else ink.copy(alpha = 0.7f))
                }
            }
        }
    }
}

@Composable
fun RecipesScreen(recipes: List<RecipeEntity>, ink: Color, a: Actions) {
    var cat by remember { mutableStateOf("Todas") }
    var q by remember { mutableStateOf("") }
    val words = q.split(",").map { it.trim() }.filter { it.isNotEmpty() }
    val shown = recipes.filter { r ->
        (cat == "Todas" || (cat == "Favoritas" && r.favorite) || r.category == cat) &&
            (words.isEmpty() || words.any {
                r.name.contains(it, true) || r.ingredients.contains(it, true) || r.tags.contains(it, true)
            })
    }
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        GlassField(q, { q = it }, "Buscar por nombre, ingrediente o etiqueta (separa con comas)", ink, Modifier.fillMaxWidth(), singleLine = true)
        LazyRow(Modifier.padding(top = 4.dp)) {
            items(listOf("Todas", "Favoritas") + CATS) { c -> GlassChip(c, c == cat, ink) { cat = c } }
        }
        if (shown.isEmpty()) {
            GlassCard(Modifier.fillMaxWidth()) {
                Text(
                    if (recipes.isEmpty()) "Aún no tienes recetas. Toca + Nueva receta para crear la primera." else "Sin resultados. Prueba con otra búsqueda o categoría.",
                    color = ink
                )
            }
        }
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            items(shown, key = { it.id }) { RecipeCard(it, ink, a) }
        }
    }
}

fun scale(line: String, f: Double): String {
    val m = Regex("^\\s*(\\d+(?:[.,]\\d+)?)(.*)$").find(line) ?: return line
    val n = m.groupValues[1].replace(',', '.').toDouble() * f
    return (if (n % 1.0 == 0.0) n.toInt().toString() else "%.1f".format(n)) + m.groupValues[2]
}

@Composable
fun RecipePhoto(path: String) {
    if (path.isBlank()) return
    val bmp = remember(path) {
        runCatching {
            val o = BitmapFactory.Options().apply { inSampleSize = 4 }
            BitmapFactory.decodeFile(path, o)?.asImageBitmap()
        }.getOrNull()
    }
    if (bmp != null) {
        Image(
            bmp, contentDescription = null, contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxWidth().height(160.dp).padding(bottom = 10.dp).clip(RoundedCornerShape(18.dp))
        )
    }
}

@Composable
fun RecipeCard(r: RecipeEntity, ink: Color, a: Actions) {
    var open by remember { mutableStateOf(false) }
    var servings by remember(r.id, r.portions) { mutableIntStateOf(r.portions) }
    val heart by animateFloatAsState(if (r.favorite) 1.25f else 1f, spring(dampingRatio = 0.3f, stiffness = 300f), label = "fav")
    GlassCard(Modifier.fillMaxWidth().animateContentSize(spring(dampingRatio = 0.6f, stiffness = 200f)).liquidClick { open = !open }) {
        RecipePhoto(r.photo)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(r.name, fontSize = 20.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Serif, color = ink)
                Text("${r.category} · ${r.minutes} min · ${r.portions} porciones", fontSize = 13.sp, color = ink.copy(alpha = 0.65f))
            }
            Text(
                if (r.favorite) "♥" else "♡", fontSize = 28.sp, color = Accent,
                modifier = Modifier.graphicsLayer { scaleX = heart; scaleY = heart }.liquidClick { a.fav(r) }.padding(8.dp)
            )
        }
        if (r.tags.isNotBlank()) Text(r.tags.split(",").filter { it.isNotBlank() }.joinToString("  ") { "#" + it.trim() }, fontSize = 12.sp, color = Accent)
        if (open) {
            Row(Modifier.padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Porciones", color = ink, modifier = Modifier.weight(1f))
                GlassButton("−", ink, small = true) { if (servings > 1) servings-- }
                Text("$servings", color = ink, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 12.dp))
                GlassButton("+", ink, small = true) { servings++ }
            }
            Spacer(Modifier.height(8.dp))
            val scaled = r.ingredients.lines().filter { it.isNotBlank() }.map { scale(it, servings.toDouble() / r.portions) }
            scaled.forEach { Text("• $it", color = ink) }
            Spacer(Modifier.height(8.dp))
            r.steps.lines().filter { it.isNotBlank() }.forEachIndexed { i, s -> StepRow(i + 1, s, ink) }
            if (r.notes.isNotBlank()) {
                Spacer(Modifier.height(8.dp))
                Text("Notas: ${r.notes}", color = ink.copy(alpha = 0.8f), fontSize = 14.sp)
            }
            if (r.cooked > 0) Text("Preparada ${r.cooked} ${if (r.cooked == 1) "vez" else "veces"}", color = ink.copy(alpha = 0.6f), fontSize = 12.sp)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassButton("Modo cocina", ink, Modifier.weight(1f), accent = true, small = true) { a.cook(r) }
                GlassButton("Preparada", ink, Modifier.weight(1f), small = true) { a.cooked(r) }
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassButton("A compras", ink, Modifier.weight(1f), small = true) { a.toList(scaled) }
                GlassButton("Editar", ink, Modifier.weight(1f), small = true) { a.edit(r) }
                GlassButton("Eliminar", ink, Modifier.weight(1f), small = true) { a.delete(r) }
            }
        }
    }
}

@Composable
fun StepRow(n: Int, text: String, ink: Color) {
    var done by remember { mutableStateOf(false) }
    Row(Modifier.fillMaxWidth().liquidClick { done = !done }.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(30.dp).glass(CircleShape, tint = if (done) Accent.copy(alpha = 0.5f) else Color.Transparent), contentAlignment = Alignment.Center) {
            Text("$n", fontSize = 12.sp, color = ink, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.width(10.dp))
        Text(
            text,
            color = ink.copy(alpha = if (done) 0.5f else 1f),
            textDecoration = if (done) TextDecoration.LineThrough else null
        )
    }
}

@Composable
fun RecipeDialog(initial: RecipeEntity?, ink: Color, onClose: () -> Unit, onSave: (RecipeEntity) -> Unit) {
    val ctx = LocalContext.current
    var n by remember { mutableStateOf(initial?.name ?: "") }
    var c by remember { mutableStateOf(initial?.category ?: "Almuerzos") }
    var t by remember { mutableStateOf((initial?.minutes ?: 30).toString()) }
    var p by remember { mutableStateOf((initial?.portions ?: 4).toString()) }
    var i by remember { mutableStateOf(initial?.ingredients ?: "") }
    var s by remember { mutableStateOf(initial?.steps ?: "") }
    var tags by remember { mutableStateOf(initial?.tags ?: "") }
    var notes by remember { mutableStateOf(initial?.notes ?: "") }
    var cost by remember { mutableStateOf(if ((initial?.cost ?: 0.0) > 0.0) initial!!.cost.toString() else "") }
    var photo by remember { mutableStateOf(initial?.photo ?: "") }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            runCatching {
                val f = File(ctx.filesDir, "photo_${System.currentTimeMillis()}.jpg")
                ctx.contentResolver.openInputStream(uri)?.use { inp -> f.outputStream().use { out -> inp.copyTo(out) } }
                photo = f.absolutePath
            }
        }
    }
    Dialog(onDismissRequest = onClose) {
        GlassCard(Modifier.fillMaxWidth().heightIn(max = 640.dp).verticalScroll(rememberScrollState()), solid = true) {
            Text(if (initial == null) "Nueva receta" else "Editar receta", fontSize = 22.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Serif, color = ink)
            GlassField(n, { n = it }, "Nombre", ink, Modifier.fillMaxWidth(), singleLine = true)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlassField(t, { t = it }, "Minutos", ink, Modifier.weight(1f), singleLine = true, number = true)
                GlassField(p, { p = it }, "Porciones", ink, Modifier.weight(1f), singleLine = true, number = true)
            }
            LazyRow(Modifier.padding(top = 4.dp)) {
                items(CATS) { k -> GlassChip(k, k == c, ink) { c = k } }
            }
            GlassField(i, { i = it }, "Ingredientes (uno por línea, ej: 2 huevos)", ink, Modifier.fillMaxWidth(), minLines = 3)
            GlassField(s, { s = it }, "Pasos (uno por línea)", ink, Modifier.fillMaxWidth(), minLines = 3)
            GlassField(tags, { tags = it }, "Etiquetas (separadas con comas)", ink, Modifier.fillMaxWidth(), singleLine = true)
            GlassField(notes, { notes = it }, "Notas personales", ink, Modifier.fillMaxWidth(), minLines = 2)
            GlassField(cost, { cost = it }, "Costo estimado por receta (opcional)", ink, Modifier.fillMaxWidth(), singleLine = true, decimal = true)
            Spacer(Modifier.height(6.dp))
            GlassButton(if (photo.isBlank()) "Añadir foto de la galería" else "Cambiar foto", ink, Modifier.fillMaxWidth(), small = true) { pick.launch("image/*") }
            Spacer(Modifier.height(10.dp))
            GlassButton("Guardar receta", ink, Modifier.fillMaxWidth(), accent = true) {
                if (n.isNotBlank()) {
                    val base = initial ?: RecipeEntity(name = "", category = c, minutes = 0, portions = 1, ingredients = "", steps = "")
                    onSave(
                        base.copy(
                            name = n.trim(), category = c, minutes = t.toIntOrNull() ?: 0,
                            portions = (p.toIntOrNull() ?: 1).coerceAtLeast(1),
                            ingredients = i.trim(), steps = s.trim(), tags = tags.trim(), notes = notes.trim(),
                            photo = photo, cost = cost.replace(',', '.').toDoubleOrNull() ?: 0.0
                        )
                    )
                }
            }
        }
    }
}

@Composable
fun CookMode(r: RecipeEntity, ink: Color, onClose: () -> Unit) {
    val steps = r.steps.lines().filter { it.isNotBlank() }
    var i by remember { mutableIntStateOf(0) }
    val done = remember { mutableStateListOf<Int>() }
    val view = LocalView.current
    DisposableEffect(Unit) {
        view.keepScreenOn = true
        onDispose { view.keepScreenOn = false }
    }
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.96f)).systemBarsPadding().padding(20.dp)) {
            Column(Modifier.fillMaxSize()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(r.name, color = ink, fontSize = 18.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Serif, modifier = Modifier.weight(1f))
                    GlassButton("Cerrar", ink, small = true) { onClose() }
                }
                if (steps.isEmpty()) {
                    Spacer(Modifier.height(24.dp))
                    Text("Esta receta aún no tiene pasos. Edítala para añadirlos.", color = ink, fontSize = 18.sp)
                } else {
                    Spacer(Modifier.height(14.dp))
                    Text("Paso ${i + 1} de ${steps.size}", color = Accent, fontWeight = FontWeight.Bold)
                    Box(Modifier.fillMaxWidth().height(10.dp).padding(top = 4.dp).clip(RoundedCornerShape(50)).background(Color.White.copy(alpha = 0.12f))) {
                        Box(Modifier.fillMaxWidth((i + 1f) / steps.size).fillMaxHeight().background(Accent))
                    }
                    Spacer(Modifier.height(24.dp))
                    Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                        Text(steps[i], color = ink, fontSize = 30.sp, lineHeight = 40.sp)
                        if (r.notes.isNotBlank()) {
                            Spacer(Modifier.height(20.dp))
                            Text("Notas: ${r.notes}", color = ink.copy(alpha = 0.7f), fontSize = 16.sp)
                        }
                    }
                    GlassButton(if (i in done) "Paso completado ✓" else "Marcar paso completado", ink, Modifier.fillMaxWidth(), accent = i in done) {
                        if (i in done) done.remove(i) else done.add(i)
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        GlassButton("Anterior", ink, Modifier.weight(1f)) { if (i > 0) i-- }
                        GlassButton("Siguiente", ink, Modifier.weight(1f), accent = true) { if (i < steps.size - 1) i++ }
                    }
                }
            }
        }
    }
}
