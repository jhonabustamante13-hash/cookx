package com.cookx.app

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val Accent = Color(0xFFFF2D3F)
val DeepRed = Color(0xFF7A0010)
val LocalShine = compositionLocalOf<State<Float>> { mutableStateOf(0f) }

/** Fondo: negro total en modo oscuro, blanco total en modo claro. */
@Composable
fun GlassBackground(content: @Composable () -> Unit) {
    val dark = true
    val t = rememberInfiniteTransition(label = "shine")
    val shine = t.animateFloat(0f, 1f, infiniteRepeatable(tween(7000, easing = LinearEasing), RepeatMode.Restart), label = "s")
    CompositionLocalProvider(LocalShine provides shine) {
        Box(
            Modifier.fillMaxSize().background(Color.Black).drawBehind {
                val dy = kotlin.math.sin(shine.value * 2f * Math.PI.toFloat()) * size.height * 0.03f
                drawRect(
                    Brush.radialGradient(
                        listOf(Accent.copy(alpha = 0.42f), DeepRed.copy(alpha = 0.20f), Color.Transparent),
                        center = Offset(size.width / 2f, size.height / 2f + dy),
                        radius = size.width * 0.95f
                    )
                )
            }
        ) { content() }
    }
}

/** Efecto liquid glass: relleno translúcido, brillo superior, borde luminoso y reflejo que se desliza. */
@Composable
fun Modifier.glass(shape: Shape = RoundedCornerShape(24.dp), tint: Color = Color.Transparent, solid: Boolean = false): Modifier {
    val dark = true
    val shine = LocalShine.current
    val base = if (dark) this else this.shadow(10.dp, shape, clip = false, ambientColor = Color.Black.copy(alpha = 0.25f), spotColor = Color.Black.copy(alpha = 0.25f))
    val rim = if (dark) Brush.linearGradient(listOf(Color.White.copy(alpha = 0.65f), Color.White.copy(alpha = 0.06f), Color.White.copy(alpha = 0.35f)))
    else Brush.linearGradient(listOf(Color.Black.copy(alpha = 0.20f), Color.Black.copy(alpha = 0.04f), Color.Black.copy(alpha = 0.14f)))
    return base.clip(shape).drawBehind {
        if (solid) drawRect(if (dark) Color(0xFF151515) else Color(0xFFF2F2F2))
        drawRect(Brush.verticalGradient(listOf(
            if (dark) Color.White.copy(alpha = 0.16f) else Color.Black.copy(alpha = 0.07f),
            if (dark) Color.White.copy(alpha = 0.04f) else Color.Black.copy(alpha = 0.03f)
        )))
        if (tint != Color.Transparent) drawRect(tint)
        drawRect(
            Brush.verticalGradient(listOf(Color.White.copy(alpha = if (dark) 0.18f else 0.75f), Color.Transparent), startY = 0f, endY = size.height * 0.5f),
            size = Size(size.width, size.height * 0.5f)
        )
        val x = size.width * (shine.value * 2.2f - 0.6f)
        drawRect(Brush.linearGradient(
            listOf(Color.Transparent, Color.White.copy(alpha = if (dark) 0.16f else 0.6f), Color.Transparent),
            start = Offset(x, 0f), end = Offset(x + size.width * 0.45f, size.height * 0.6f)
        ))
    }.border(1.dp, rim, shape)
}

/** Clic con rebote líquido. */
@Composable
fun Modifier.liquidClick(onClick: () -> Unit): Modifier {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val sc by animateFloatAsState(if (pressed) 0.93f else 1f, spring(dampingRatio = 0.4f, stiffness = 400f), label = "press")
    return this.graphicsLayer { scaleX = sc; scaleY = sc }.clickable(interactionSource = src, indication = null, onClick = onClick)
}

@Composable
fun GlassCard(modifier: Modifier = Modifier, radius: Dp = 26.dp, solid: Boolean = false, content: @Composable ColumnScope.() -> Unit) {
    Column(modifier.glass(RoundedCornerShape(radius), solid = solid).padding(16.dp), content = content)
}

@Composable
fun GlassButton(text: String, ink: Color, modifier: Modifier = Modifier, accent: Boolean = false, small: Boolean = false, onClick: () -> Unit) {
    Box(
        modifier.liquidClick(onClick)
            .glass(RoundedCornerShape(50), tint = if (accent) Accent.copy(alpha = 0.40f) else Color.Transparent)
            .padding(horizontal = if (small) 14.dp else 20.dp, vertical = if (small) 6.dp else 12.dp),
        contentAlignment = Alignment.Center
    ) { Text(text, color = ink, fontWeight = FontWeight.SemiBold) }
}

@Composable
fun GlassChip(text: String, selected: Boolean, ink: Color, onClick: () -> Unit) {
    Box(Modifier.padding(end = 8.dp, top = 4.dp, bottom = 8.dp)) {
        Box(
            Modifier.liquidClick(onClick)
                .glass(RoundedCornerShape(50), tint = if (selected) Accent.copy(alpha = 0.45f) else Color.Transparent)
                .padding(horizontal = 16.dp, vertical = 9.dp)
        ) { Text(text, color = ink, fontSize = 14.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal) }
    }
}

@Composable
fun GlassField(value: String, onChange: (String) -> Unit, label: String, ink: Color, modifier: Modifier = Modifier, singleLine: Boolean = false, minLines: Int = 1, number: Boolean = false, decimal: Boolean = false) {
    Column(modifier.padding(vertical = 4.dp).glass(RoundedCornerShape(20.dp)).padding(horizontal = 16.dp, vertical = 10.dp)) {
        Text(label, fontSize = 11.sp, color = ink.copy(alpha = 0.6f))
        BasicTextField(
            value, onChange,
            modifier = Modifier.fillMaxWidth(),
            textStyle = TextStyle(color = ink, fontSize = 16.sp),
            cursorBrush = SolidColor(Accent),
            singleLine = singleLine,
            minLines = minLines,
            keyboardOptions = KeyboardOptions(keyboardType = if (decimal) KeyboardType.Decimal else if (number) KeyboardType.Number else KeyboardType.Text)
        )
    }
}

/** Burbuja de cristal esférica (como `.bd` del index): brillo arriba-izquierda, resplandor rojo abajo-derecha y borde luminoso. */
@Composable
fun Modifier.glassBubble(): Modifier {
    val white0 = Color.White.copy(alpha = 0f)
    return this.clip(CircleShape).drawBehind {
        val w = size.width
        drawRect(Color.White.copy(alpha = 0.07f))
        drawRect(
            Brush.radialGradient(
                0f to Color.White.copy(alpha = 0.80f),
                0.36f to Color.White.copy(alpha = 0.14f),
                1f to white0,
                center = Offset(w * 0.30f, size.height * 0.24f),
                radius = w * 0.58f
            )
        )
        drawRect(
            Brush.radialGradient(
                0f to Accent.copy(alpha = 0.40f),
                1f to Accent.copy(alpha = 0f),
                center = Offset(w * 0.72f, size.height * 0.82f),
                radius = w * 0.62f
            )
        )
        drawRect(
            Brush.verticalGradient(listOf(white0, Color.White.copy(alpha = 0.14f)), startY = size.height * 0.55f, endY = size.height)
        )
    }.border(1.dp, Color.White.copy(alpha = 0.40f), CircleShape)
}

/** Iconos de las pestañas en liquid glass: 0 recetas, 1 plan, 2 compras, 3 útiles, 4 datos. */
private val TAB_EMOJI = listOf("🍳", "📅", "🛒", "⏱", "📊")

@Composable
fun GlassIcon(kind: Int, selected: Boolean, ink: Color) {
    LiquidIcon(TAB_EMOJI[kind.coerceIn(0, TAB_EMOJI.size - 1)], 22.dp, if (selected) Accent else Color.White)
}
