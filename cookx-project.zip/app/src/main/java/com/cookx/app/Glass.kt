package com.cookx.app

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

val Accent = Color(0xFFD4562B)

private fun DrawScope.blob(c: Color, o: Offset, r: Float) =
    drawCircle(Brush.radialGradient(listOf(c, Color.Transparent), center = o, radius = r), radius = r, center = o)

/** Fondo líquido: manchas de color que se mueven despacio. */
@Composable
fun LiquidBackground(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val t = rememberInfiniteTransition(label = "liquid")
    val a by t.animateFloat(0f, 1f, infiniteRepeatable(tween(18000, easing = LinearEasing), RepeatMode.Reverse), label = "a")
    val b by t.animateFloat(0f, 1f, infiniteRepeatable(tween(23000, easing = LinearEasing), RepeatMode.Reverse), label = "b")
    Box(Modifier.fillMaxSize().background(if (dark) Color(0xFF2A1810) else Color(0xFFF6D9B8))) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            blob(Accent.copy(alpha = 0.75f), Offset(w * (0.15f + 0.6f * a), h * (0.12f + 0.3f * b)), w * 0.6f)
            blob(Color(0xFFFFB36B).copy(alpha = 0.75f), Offset(w * (0.9f - 0.6f * b), h * (0.4f + 0.2f * a)), w * 0.55f)
            blob(Color(0xFFE86A8A).copy(alpha = 0.65f), Offset(w * (0.3f + 0.4f * b), h * (0.95f - 0.3f * a)), w * 0.6f)
            blob(Color(0xFF7CC08A).copy(alpha = 0.6f), Offset(w * (0.8f - 0.3f * a), h * (0.75f - 0.2f * b)), w * 0.45f)
        }
        content()
    }
}

/** Tarjeta de cristal: relleno translúcido y borde luminoso. */
@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    radius: Dp = 24.dp,
    solid: Boolean = false,
    content: @Composable ColumnScope.() -> Unit
) {
    val dark = isSystemInDarkTheme()
    val fill = when {
        solid && dark -> Color(0xF22A1810)
        solid -> Color(0xF2FFF4E8)
        dark -> Color.White.copy(alpha = 0.10f)
        else -> Color.White.copy(alpha = 0.42f)
    }
    val edge = Brush.linearGradient(listOf(Color.White.copy(alpha = 0.85f), Color.White.copy(alpha = 0.10f), Color.White.copy(alpha = 0.45f)))
    val s = RoundedCornerShape(radius)
    Column(modifier.clip(s).background(fill).border(1.dp, edge, s).padding(16.dp), content = content)
}
