package com.cookx.app

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// =====================================================================
//  ICONOS LIQUID GLASS (vectoriales, idénticos a los del index.html)
//  Cada icono se dibuja en una cuadrícula de 24x24: relleno translúcido
//  de color + borde blanco + brillo degradado + reflejo.
// =====================================================================

private val ICON_PATHS: Map<String, List<String>> = mapOf(
    "ap" to listOf("M12 8C10 6 6 6.500 5 11c-1 4.500 2 10 5 10 1 0 1.500-.5 2-.5s1 .5 2 .5c3 0 6-5.500 5-10-1-4.500-5-5-7-3z", "M12 8c0-2 1-4 3.500-4.500"),
    "lem" to listOf("M3.500 12c1-4 5-7 8.500-7s7.500 3 8.500 7c-1 4-5 7-8.500 7S4.500 16 3.500 12z"),
    "grp" to listOf("M5.4 10A3.6 3.6 0 1 0 12.6 10A3.6 3.6 0 1 0 5.4 10Z", "M11.4 10A3.6 3.6 0 1 0 18.6 10A3.6 3.6 0 1 0 11.4 10Z", "M8.4 15.5A3.6 3.6 0 1 0 15.6 15.5A3.6 3.6 0 1 0 8.4 15.5Z", "M12 7V3.500l3-1"),
    "ban" to listOf("M4 8c1 8 8 13 17 11-1-2-3-3-5-3.500C11 15 8 12 8 8z", "M4 8l1.500-3 2 1"),
    "str" to listOf("M12 21C7 18 4 13.500 5 10c1-3 4-3.500 7-2 3-1.500 6-1 7 2 1 3.500-2 8-7 11z", "M9 5l3 3 3-3"),
    "car" to listOf("M16 7C9 8 4 16 4 20c4 0 12-4 14-11 1-3-1-3-2-2z", "M17 7c1-2 2.500-3 4.500-3M17 7c2 0 3.500 1 4 3"),
    "onn" to listOf("M12 4c1 3 6 5 6 11 0 3.500-3 6-6 6s-6-2.500-6-6c0-6 5-8 6-11z"),
    "gar" to listOf("M12 3c1.500 3 7 5 7 11 0 4-3.500 7-7 7s-7-3-7-7c0-6 5.500-8 7-11z", "M12 8v10"),
    "pot" to listOf("M5 10c0-3.500 4-5 8-5s7 2.500 6.500 7c-.5 4.500-5 7.500-9 7-4-.5-5.500-5-5.500-9z"),
    "pep" to listOf("M8 8c2-2 8-2 9 1 1 4 0 9-3 12-1 1-3 .5-4-1-2-3-3-8-2-12z", "M12 7c0-2 0-3 2-4"),
    "mus" to listOf("M3 12c0-5 4-8 9-8s9 3 9 8z", "M9 12h6v7c0 1-1 2-3 2s-3-1-3-2z"),
    "brc" to listOf("M3.5 9A4.5 4.5 0 1 0 12.5 9A4.5 4.5 0 1 0 3.5 9Z", "M11.5 9A4.5 4.5 0 1 0 20.5 9A4.5 4.5 0 1 0 11.5 9Z", "M7.5 6.5A4.5 4.5 0 1 0 16.5 6.5A4.5 4.5 0 1 0 7.5 6.5Z", "M10 12h4l1 9H9z"),
    "lef" to listOf("M4 20C3 10 9 3 20 4c1 11-5 17-14 16z", "M4 20c4-6 7-9 12-11"),
    "egp" to listOf("M17 5c3 0 4 2 3 5-1 5-6 11-11 11-3 0-5-2-4-5 1-6 7-11 12-11z", "M17 5c0-1.500 1-2.500 3-2.500"),
    "crn" to listOf("M12 3c3 0 4 3 4 7 0 5-1 9-4 11-3-2-4-6-4-11 0-4 1-7 4-7z", "M4 21c3-1 5-4 6-8M20 21c-3-1-5-4-6-8"),
    "drm" to listOf("M8.5 9A6.5 6.5 0 1 0 21.5 9A6.5 6.5 0 1 0 8.5 9Z", "M10 14l-5 5M4 17.500a2 2 0 1 0 2 2"),
    "stk" to listOf("M4 12c0-5 5-8 10-8 4 0 7 3 6 7-1 5-5 9-10 9-4 0-6-3-6-8z", "M11.5 11A2.5 2.5 0 1 0 16.5 11A2.5 2.5 0 1 0 11.5 11Z"),
    "fsh" to listOf("M3 12c4-5 10-6 14-2l4-4v12l-4-4c-4 4-10 3-14-2z", "M7 11A1 1 0 1 0 9 11A1 1 0 1 0 7 11Z"),
    "shr" to listOf("M17 5c3 2 3 7 0 10-2 2-5 3-9 2l-3 3 .5-4C3 14 4 8 8 6c3-1.500 6-2 9-1z"),
    "egg" to listOf("M12 3c4 0 7 6 7 11 0 4-3 7-7 7s-7-3-7-7C5 9 8 3 12 3z"),
    "mlk" to listOf("M9 3h6v4l3 3v10c0 1-1 2-2 2H8c-1 0-2-1-2-2V10l3-3z", "M6 12h12"),
    "chs" to listOf("M3 17l18-4V8L3 5z", "M3 17v3h18v-7", "M7.8 11A1.2 1.2 0 1 0 10.2 11A1.2 1.2 0 1 0 7.8 11Z", "M13.8 10A1.2 1.2 0 1 0 16.2 10A1.2 1.2 0 1 0 13.8 10Z"),
    "whe" to listOf("M12 21V9", "M12 9c-3 0-4-2-4-4 3 0 4 2 4 4zM12 9c3 0 4-2 4-4-3 0-4 2-4 4zM12 14c-3 0-4-2-4-4 3 0 4 2 4 4zM12 14c3 0 4-2 4-4-3 0-4 2-4 4z"),
    "slt" to listOf("M8 8h8l1 3H7z", "M7 11h10l-1 9c0 1-1 1-2 1h-4c-1 0-2 0-2-1z"),
    "sug" to listOf("M3 9l9-4 9 4v8l-9 4-9-4z", "M3 9l9 4 9-4M12 13v8"),
    "oil" to listOf("M12 3c4 5 7 8 7 12a7 7 0 0 1-14 0c0-4 3-7 7-12z"),
    "bwl" to listOf("M3 11h18c0 6-3 10-9 10S3 17 3 11z", "M8 8c1-2 2-2 1-4M13 8c1-2 2-2 1-4"),
    "brd" to listOf("M4 11c0-4 4-6 8-6s8 2 8 6c0 1-1 1.500-1 2v6c0 1-1 1-2 1H7c-1 0-2 0-2-1v-6c0-.5-1-1-1-2z"),
    "jar" to listOf("M7 4h10v3c2 1 3 3 3 5v6c0 2-1 3-3 3H7c-2 0-3-1-3-3v-6c0-2 1-4 3-5z", "M5 12h14"),
    "cho" to listOf("M5 4h14v16H5z", "M5 9h14M5 14h14M10 4v16M14 4v16"),
    "bea" to listOf("M7 5c5-2 12 2 11 8-1 6-8 8-11 4-3-3-3-9 0-12z"),
    "nut" to listOf("M12 3c5 0 8 4 7 9-1 5-4 9-7 9s-6-4-7-9c-1-5 2-9 7-9z", "M12 3v18"),
    "cup" to listOf("M5 8h12v7c0 3-2 5-6 5s-6-2-6-5z", "M17 10h2a2 2 0 0 1 0 5h-2M8 3c1 1 1 2 0 3M12 3c1 1 1 2 0 3"),
    "win" to listOf("M6 4h12l-1 8c0 3-2 5-5 5s-5-2-5-5z", "M12 17v4M8 21h8"),
    "pla" to listOf("M3 12A9 9 0 1 0 21 12A9 9 0 1 0 3 12Z", "M7 12A5 5 0 1 0 17 12A5 5 0 1 0 7 12Z"),
    "hat" to listOf("M7 20h10v-4c3 0 5-2 5-5s-3-5-5-4c-1-2-4-2-5 0-2-1-5 1-5 4s2 5 5 5z", "M7 17h10"),
    "cal" to listOf("M4 6h16v14H4z", "M4 11h16M8 3v5M16 3v5"),
    "car2" to listOf("M3 4h3l2 12h11l2-8H7", "M8.3 20A1.7 1.7 0 1 0 11.7 20A1.7 1.7 0 1 0 8.3 20Z", "M15.3 20A1.7 1.7 0 1 0 18.7 20A1.7 1.7 0 1 0 15.3 20Z"),
    "tim" to listOf("M4 13A8 8 0 1 0 20 13A8 8 0 1 0 4 13Z", "M12 8v5l3 2M9 2h6"),
    "bar" to listOf("M5.5 12L6.5 12A1.5 1.5 0 0 1 8 13.5L8 18.5A1.5 1.5 0 0 1 6.5 20L5.5 20A1.5 1.5 0 0 1 4 18.5L4 13.5A1.5 1.5 0 0 1 5.5 12Z", "M11.5 7L12.5 7A1.5 1.5 0 0 1 14 8.5L14 18.5A1.5 1.5 0 0 1 12.5 20L11.5 20A1.5 1.5 0 0 1 10 18.5L10 8.5A1.5 1.5 0 0 1 11.5 7Z", "M17.5 3L18.5 3A1.5 1.5 0 0 1 20 4.5L20 18.5A1.5 1.5 0 0 1 18.5 20L17.5 20A1.5 1.5 0 0 1 16 18.5L16 4.5A1.5 1.5 0 0 1 17.5 3Z")
)

/** Emoji -> (icono, color base). */
private val ICON_FOR_EMOJI: Map<String, Pair<String, Long>> = mapOf(
    "🥥" to ("nut" to 0xFFE8E0D0),
    "🍅" to ("ap" to 0xFFFF3B3B),
    "🧀" to ("chs" to 0xFFFFC23D),
    "🥛" to ("mlk" to 0xFFDBE9FF),
    "🧈" to ("sug" to 0xFFFFE27A),
    "🥚" to ("egg" to 0xFFFFF3D6),
    "🌾" to ("whe" to 0xFFE8C36A),
    "🍬" to ("sug" to 0xFFFF9AD5),
    "🧂" to ("slt" to 0xFFDFE6EE),
    "🫑" to ("pep" to 0xFF3FD16A),
    "🌶️" to ("pep" to 0xFFFF3B30),
    "🧅" to ("onn" to 0xFFC77DFF),
    "🧄" to ("gar" to 0xFFF2EADF),
    "🥔" to ("pot" to 0xFFD9A566),
    "🥕" to ("car" to 0xFFFF8A3D),
    "🌽" to ("crn" to 0xFFFFD23D),
    "🥦" to ("brc" to 0xFF3FD16A),
    "🥬" to ("lef" to 0xFF6FE08A),
    "🥒" to ("egp" to 0xFF4BD16A),
    "🍆" to ("egp" to 0xFF8B4DFF),
    "🍄" to ("mus" to 0xFFFF6B6B),
    "🥑" to ("egg" to 0xFF8FD14F),
    "🌿" to ("lef" to 0xFF3FD16A),
    "🍋" to ("lem" to 0xFFFFE14D),
    "🍊" to ("ap" to 0xFFFF9A2E),
    "🍎" to ("ap" to 0xFFFF3B4A),
    "🍐" to ("ap" to 0xFFB6E04A),
    "🍌" to ("ban" to 0xFFFFE14D),
    "🍓" to ("str" to 0xFFFF3B5C),
    "🍇" to ("grp" to 0xFF9B5CFF),
    "🍒" to ("grp" to 0xFFFF2D55),
    "🍑" to ("ap" to 0xFFFFA38A),
    "🍍" to ("egg" to 0xFFFFD23D),
    "🥭" to ("ap" to 0xFFFFA63D),
    "🍉" to ("lem" to 0xFFFF5A6A),
    "🍈" to ("ap" to 0xFFB8F07A),
    "🥝" to ("ap" to 0xFF8FD14F),
    "🎃" to ("ap" to 0xFFFF8A1A),
    "🫒" to ("oil" to 0xFF9ACD32),
    "🌰" to ("bea" to 0xFFC28A5A),
    "🥜" to ("nut" to 0xFFD9A066),
    "🍚" to ("bwl" to 0xFFFFFFFF),
    "🍝" to ("bwl" to 0xFFFFB84D),
    "🍞" to ("brd" to 0xFFE0A050),
    "🥐" to ("brd" to 0xFFE0A050),
    "🌮" to ("brd" to 0xFFFFD23D),
    "🍗" to ("drm" to 0xFFE08A3D),
    "🥩" to ("stk" to 0xFFFF4D5A),
    "🥓" to ("stk" to 0xFFFF7A7A),
    "🐟" to ("fsh" to 0xFF5CC8FF),
    "🦐" to ("shr" to 0xFFFF8A6B),
    "🍯" to ("jar" to 0xFFFFB400),
    "🍫" to ("cho" to 0xFF8B5A3C),
    "🍲" to ("bwl" to 0xFFFF6B3D),
    "🥫" to ("jar" to 0xFFFF5A4D),
    "💧" to ("oil" to 0xFF5CC8FF),
    "🍽️" to ("pla" to 0xFFFFFFFF),
    "🥤" to ("cup" to 0xFF5CC8FF),
    "🧴" to ("jar" to 0xFF99AADD),
    "🧊" to ("egg" to 0xFFBFE8FF),
    "🍪" to ("pla" to 0xFFD9A066),
    "☕" to ("cup" to 0xFF8B5A3C),
    "🍵" to ("cup" to 0xFF6FE08A),
    "🍷" to ("win" to 0xFFB3003C),
    "🍠" to ("pot" to 0xFFFF7A5C),
    "🍶" to ("jar" to 0xFFCCDDEE),
    "🍳" to ("hat" to 0xFFFF2D3F),
    "📅" to ("cal" to 0xFFFFFFFF),
    "🛒" to ("car2" to 0xFFFF6B78),
    "⏱" to ("tim" to 0xFFFFFFFF),
    "📊" to ("bar" to 0xFFFFFFFF),
    "🍨" to ("cup" to 0xFFFF9AD5)
)

private class ParsedIcon(val paths: List<Path>, val bounds: Rect)

private val PARSED: Map<String, ParsedIcon> by lazy {
    ICON_PATHS.mapValues { (_, ds) ->
        val ps = ds.map { PathParser().parsePathString(it).toPath() }
        var b = ps.first().getBounds()
        for (p in ps.drop(1)) {
            val r = p.getBounds()
            b = Rect(minOf(b.left, r.left), minOf(b.top, r.top), maxOf(b.right, r.right), maxOf(b.bottom, r.bottom))
        }
        ParsedIcon(ps, b)
    }
}

/** true si existe un icono liquid glass para ese emoji. */
fun hasLiquidIcon(emoji: String): Boolean = ICON_FOR_EMOJI.containsKey(emoji)

/** Icono liquid glass del alimento/símbolo. `color` reemplaza el color base (p. ej. pestaña activa). */
@Composable
fun LiquidIcon(emoji: String, size: Dp, color: Color? = null) {
    val def = ICON_FOR_EMOJI[emoji]
    val icon = def?.let { PARSED[it.first] }
    if (def == null || icon == null) {
        Text(emoji, fontSize = (size.value * 0.9f).sp)
        return
    }
    val base = color ?: Color(def.second)
    val b = icon.bounds
    val sheen = remember(b) {
        Brush.linearGradient(
            0f to Color.White.copy(alpha = 0.85f),
            0.5f to Color.White.copy(alpha = 0.10f),
            1f to Color.White.copy(alpha = 0.30f),
            start = Offset(b.left, b.top),
            end = Offset(b.right, b.bottom)
        )
    }
    Canvas(Modifier.size(size)) {
        val s = this.size.minDimension / 24f
        scale(s, s, pivot = Offset.Zero) {
            for (p in icon.paths) drawPath(p, base.copy(alpha = 0.55f))
            for (p in icon.paths) drawPath(
                p, Color.White.copy(alpha = 0.9f),
                style = Stroke(0.9f, cap = StrokeCap.Round, join = StrokeJoin.Round)
            )
            for (p in icon.paths) drawPath(p, sheen)
            rotate(-35f, pivot = Offset(8.5f, 8f)) {
                drawOval(Color.White.copy(alpha = 0.8f), Offset(6.5f, 7f), Size(4f, 2f))
            }
        }
    }
}

/** Burbuja de cristal con un icono dentro (como `.bd` del index). */
@Composable
fun IconBubble(emoji: String, size: Dp, color: Color? = null, checked: Boolean = false) {
    Box(
        Modifier.size(size).glassBubble(),
        contentAlignment = Alignment.Center
    ) { LiquidIcon(emoji, size * 0.58f, color) }
}
