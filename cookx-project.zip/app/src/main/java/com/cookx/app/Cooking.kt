package com.cookx.app

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

// =====================================================================
//  ACCIONES DE COCINA: detección en el texto del paso
// =====================================================================

enum class CookAction(val label: String) {
    CUT("Picando"), BLEND("Triturando"), WHISK("Batiendo"), KNEAD("Amasando"),
    BOIL("Hirviendo"), FRY("Friendo"), BAKE("Horneando"), GRILL("Asando"),
    REST("Reposando"), PEEL("Pelando"), GRATE("Rallando"), POUR("Vertiendo"),
    SEASON("Sazonando"), SERVE("Sirviendo")
}

private val MARKS = Regex("\\p{M}+")

/** Minúsculas y sin acentos (ñ -> n), para comparar texto. */
fun normText(s: String): String =
    java.text.Normalizer.normalize(s.lowercase(), java.text.Normalizer.Form.NFD).replace(MARKS, "")

private val ACTION_RULES: List<Pair<CookAction, Regex>> = listOf(
    CookAction.CUT to Regex("\\b(?:pic(?:a|ar|ad\\w*|and\\w*|e|en)\\b|cort\\w*|trocea\\w*|rebana\\w*|dice\\w*|dados?\\b|juliana|filetea\\w*|laminas?\\b)"),
    CookAction.BLEND to Regex("\\b(?:tritur\\w*|licu\\w*|muel\\w*|molid\\w*|moler|proces\\w*|pulveriz\\w*|pure\\b|machac\\w*|aplast\\w*)"),
    CookAction.WHISK to Regex("\\b(?:bat(?:e|ir|ed|id\\w*|iend\\w*)\\b|mezcl\\w*|revuel\\w*|remuev\\w*|remov\\w*|integr\\w*|incorpor\\w*|emulsion\\w*|agit\\w*|mueve\\b|mover\\b)"),
    CookAction.KNEAD to Regex("\\b(?:amas\\w*|estir\\w*|extiend\\w*|extender|enroll\\w*)"),
    CookAction.BOIL to Regex("\\b(?:herv\\w*|hierv\\w*|hirv\\w*|coc(?:er|e|id\\w*|in\\w*|iend\\w*|cion)\\b|cuec\\w*|escald\\w*|blanque\\w*|guis\\w*|estof\\w*|ebull\\w*|sumerg\\w*)"),
    CookAction.FRY to Regex("\\b(?:freir\\w*|frie\\w*|frit\\w*|salte\\w*|sofr\\w*|dor(?:a|ar|ad\\w*|e|en)\\b|sella\\w*|rehog\\w*|sarten|wok|comal)"),
    CookAction.BAKE to Regex("\\b(?:horn\\w*|gratin\\w*|precalient\\w*)"),
    CookAction.GRILL to Regex("\\b(?:asa\\b|asar\\b|asad\\w*|asand\\w*|parrill\\w*|brasa\\w*|barbacoa|tosta\\w*|plancha|grill\\w*)"),
    CookAction.REST to Regex("\\b(?:repos\\w*|enfri\\w*|refriger\\w*|marin\\w*|leud\\w*|fermen\\w*|esper\\w*|descans\\w*|congel\\w*|templ\\w*|nevera|heladera)"),
    CookAction.PEEL to Regex("\\b(?:pel(?:a|ar|ad\\w*|e|en|and\\w*)\\b|descascar\\w*|mond\\w*)"),
    CookAction.GRATE to Regex("\\b(?:rall\\w*)"),
    CookAction.POUR to Regex("\\b(?:vert\\w*|viert\\w*|vuelc\\w*|ech(?:a|ar|ad\\w*|e|en|and\\w*)\\b|anad\\w*|agreg\\w*|rocia\\w*|rellen\\w*|llen\\w*)"),
    CookAction.SEASON to Regex("\\b(?:sazon\\w*|salpiment\\w*|condiment\\w*|espolvor\\w*|sal\\b|salar\\b|pimienta|pizca|especias?\\b|aderez\\w*)"),
    CookAction.SERVE to Regex("\\b(?:sirv\\w*|servi\\w*|emplat\\w*|decor\\w*|adorn\\w*|guarn\\w*|acompan\\w*|disfrut\\w*)")
)

/** Acciones encontradas en el paso, en el orden en que aparecen (máximo 3). */
fun detectActions(step: String): List<CookAction> {
    val t = normText(step)
    return ACTION_RULES
        .mapNotNull { (a, r) -> r.find(t)?.let { m -> a to m.range.first } }
        .sortedBy { it.second }
        .map { it.first }
        .take(3)
}

// =====================================================================
//  ESCENAS ANIMADAS (se dibujan en un espacio de -50..50)
// =====================================================================

private val CxSteel = Color(0xFFD5DAE0)
private val CxDark = Color(0xFF26262B)
private val CxWood = Color(0xFFB9824F)
private val CxCarrot = Color(0xFFFF8A3D)
private val CxGold = Color(0xFFFFC857)
private val CxWater = Color(0xFF7CC8FF)
private val CxCream = Color(0xFFF6E7CF)
private val CxGreen = Color(0xFF6CC070)
private val CxSkin = Color(0xFFFFC9A3)

private fun Color.a(x: Float): Color = copy(alpha = x)

/** Onda periódica: k ciclos por vuelta de animación, ph = desfase (0..1). */
private fun cxWave(p: Float, k: Int = 1, ph: Float = 0f): Float = sin((p * k + ph) * 2f * PI.toFloat())

private fun DrawScope.flame(x: Float, base: Float, h: Float, wd: Float, c: Color) {
    val f = Path().apply {
        moveTo(x, base)
        quadraticBezierTo(x - wd, base - h * 0.45f, x, base - h)
        quadraticBezierTo(x + wd, base - h * 0.45f, x, base)
        close()
    }
    drawPath(f, c)
}

private fun DrawScope.sparkle(c: Offset, s: Float, color: Color) {
    if (s <= 0.1f) return
    drawLine(color, Offset(c.x - s, c.y), Offset(c.x + s, c.y), 1.6f, StrokeCap.Round)
    drawLine(color, Offset(c.x, c.y - s), Offset(c.x, c.y + s), 1.6f, StrokeCap.Round)
}

private fun DrawScope.sceneCut(p: Float) {
    drawRoundRect(CxWood, Offset(-46f, 20f), Size(92f, 20f), CornerRadius(6f))
    drawRoundRect(Color.White.a(0.22f), Offset(-46f, 20f), Size(92f, 5f), CornerRadius(5f))
    val gap = 1.5f + 6f * (0.5f + 0.5f * cxWave(p, 2, -0.25f))
    val total = 5 * 10f + 4 * gap
    for (i in 0 until 5) {
        val x = -total / 2f + i * (10f + gap)
        drawRoundRect(CxCarrot, Offset(x, 4f), Size(10f, 16f), CornerRadius(3f))
        drawRoundRect(Color.White.a(0.3f), Offset(x + 1.5f, 6f), Size(2.5f, 11f), CornerRadius(1.5f))
    }
    val d = 0.5f + 0.5f * cxWave(p, 2)
    translate(-22f, -40f + 40f * d) {
        val blade = Path().apply {
            moveTo(0f, 0f); lineTo(34f, 0f); lineTo(34f, 6f); lineTo(30f, 9f); lineTo(0f, 9f); close()
        }
        drawPath(blade, CxSteel)
        drawRoundRect(CxDark, Offset(34f, -1f), Size(18f, 8f), CornerRadius(4f))
    }
}

private fun DrawScope.sceneBlend(p: Float) {
    translate(0.8f * cxWave(p, 8), 0f) {
        drawRoundRect(CxDark, Offset(-22f, 30f), Size(44f, 14f), CornerRadius(5f))
        drawCircle(Accent, 2f, Offset(0f, 37f))
        val jar = Path().apply {
            moveTo(-24f, -34f); lineTo(24f, -34f); lineTo(16f, 30f); lineTo(-16f, 30f); close()
        }
        drawPath(jar, Color.White.a(0.12f))
        clipPath(jar) {
            val liquid = Path().apply {
                moveTo(-30f, -6f)
                var x = -30f
                while (x <= 30f) {
                    lineTo(x, -6f + 2.5f * cxWave(p, 3, x / 60f))
                    x += 2f
                }
                lineTo(30f, 40f); lineTo(-30f, 40f); close()
            }
            drawPath(liquid, Accent.a(0.9f))
            for (i in 0 until 7) {
                val ang = (p * 3f + i / 7f) * 2f * PI.toFloat()
                val r = 3f + i * 1.8f
                drawCircle(Color.White.a(0.55f), 1.6f, Offset(cos(ang) * r, 14f + sin(ang) * r * 0.3f - i * 1.5f))
            }
        }
        val spin = p * 3f * 2f * PI.toFloat()
        drawLine(CxSteel, Offset(-10f * cos(spin), 26f), Offset(10f * cos(spin), 26f), 2.6f, StrokeCap.Round)
        drawPath(jar, Color.White.a(0.9f), style = Stroke(2f))
        drawRoundRect(CxDark, Offset(-27f, -41f), Size(54f, 8f), CornerRadius(3f))
    }
}

private fun DrawScope.sceneWhisk(p: Float) {
    val bowl = Path().apply {
        moveTo(-38f, -2f); lineTo(38f, -2f)
        cubicTo(36f, 32f, 16f, 42f, 0f, 42f)
        cubicTo(-16f, 42f, -36f, 32f, -38f, -2f)
        close()
    }
    drawPath(bowl, Color.White.a(0.14f))
    clipPath(bowl) { drawRect(CxGold.a(0.85f), Offset(-40f, -2f), Size(80f, 46f)) }
    drawOval(CxGold, Offset(-37f, -8f), Size(74f, 12f))
    for (k in 0 until 3) {
        drawArc(
            color = Color.White.a(0.6f), startAngle = p * 360f + k * 120f, sweepAngle = 70f, useCenter = false,
            topLeft = Offset(-26f + k * 6f, -6f + k * 1.2f), size = Size(52f - k * 12f, 8f - k * 1.6f),
            style = Stroke(1.8f, cap = StrokeCap.Round)
        )
    }
    drawPath(bowl, Color.White.a(0.85f), style = Stroke(2f))
    val ang = p * 2f * PI.toFloat()
    val hx = cos(ang) * 9f
    val tx = cos(ang - 0.6f) * 5f
    drawLine(CxSteel, Offset(hx, -46f), Offset(tx, -4f), 3f, StrokeCap.Round)
    for (wd in listOf(12f, 8f, 4f)) {
        drawOval(CxSteel.a(0.9f), Offset(tx - wd / 2f, -10f), Size(wd, 18f), style = Stroke(1.2f))
    }
    drawLine(Accent, Offset(hx, -46f), Offset(hx * 0.8f + tx * 0.2f, -30f), 5f, StrokeCap.Round)
    for (i in 0 until 4) {
        val q = (p * 2f + i / 4f) % 1f
        drawCircle(Color.White.a(0.7f * (1f - q)), 2.2f * (1f - q) + 0.5f, Offset(-22f + i * 14f, -4f - q * 18f))
    }
}

private fun DrawScope.sceneKnead(p: Float) {
    drawRoundRect(CxWood, Offset(-46f, 24f), Size(92f, 10f), CornerRadius(5f))
    val s = 0.5f + 0.5f * cxWave(p, 2)
    val h = 22f - 9f * s
    val wd = 40f + 12f * s
    drawOval(CxCream, Offset(-wd / 2f, 24f - h), Size(wd, h))
    drawOval(Color.White.a(0.35f), Offset(-wd / 2f + 6f, 24f - h + 2f), Size(wd * 0.4f, h * 0.3f))
    val hy = 24f - h - 2f
    drawRoundRect(CxSkin, Offset(-9f, hy - 46f), Size(18f, 30f), CornerRadius(6f))
    drawRoundRect(CxSkin, Offset(-14f, hy - 22f), Size(28f, 22f), CornerRadius(11f))
    drawRoundRect(CxSkin, Offset(-20f, hy - 14f), Size(10f, 8f), CornerRadius(4f))
    for (i in 0 until 3) {
        drawCircle(Color.White.a(0.5f * s), 2f + i * 0.6f, Offset(-wd / 2f - 3f - i * 3f, 20f - i * 4f))
        drawCircle(Color.White.a(0.5f * s), 2f + i * 0.6f, Offset(wd / 2f + 3f + i * 3f, 20f - i * 4f))
    }
}

private fun DrawScope.sceneBoil(p: Float) {
    drawRoundRect(CxDark, Offset(-38f, 41f), Size(76f, 5f), CornerRadius(2.5f))
    for (i in 0 until 3) {
        flame(-18f + i * 18f, 41f, 5f + 2f * cxWave(p, 5, i * 0.3f) + 2f, 4f, Accent.a(0.9f))
    }
    drawRoundRect(Color.White.a(0.14f), Offset(-30f, -4f), Size(60f, 40f), CornerRadius(8f))
    drawRoundRect(CxWater.a(0.45f), Offset(-29f, 6f), Size(58f, 29f), CornerRadius(7f))
    for (i in 0 until 7) {
        val q = (p + i / 7f) % 1f
        val x = -22f + ((i * 17) % 44)
        drawCircle(Color.White.a(0.8f * (1f - q * 0.7f)), 1.5f + (i % 3) * 0.8f, Offset(x, 32f - q * 28f))
    }
    drawRoundRect(Color.White.a(0.7f), Offset(-30f, -4f), Size(60f, 40f), CornerRadius(8f), style = Stroke(1.6f))
    drawRoundRect(CxSteel, Offset(-40f, 4f), Size(10f, 5f), CornerRadius(2.5f))
    drawRoundRect(CxSteel, Offset(30f, 4f), Size(10f, 5f), CornerRadius(2.5f))
    val lift = -3f * max(0f, cxWave(p, 4))
    drawArc(
        color = CxSteel, startAngle = 180f, sweepAngle = 180f, useCenter = true,
        topLeft = Offset(-32f, -26f + lift), size = Size(64f, 40f)
    )
    drawCircle(Accent, 3.2f, Offset(0f, -27f + lift))
    for (i in 0 until 8) {
        val q = (p + i / 8f) % 1f
        val x = -14f + (i % 3) * 14f + 3f * cxWave(q, 2, i * 0.13f)
        drawCircle(Color.White.a(0.35f * (1f - q)), 3f + q * 5f, Offset(x, -12f - q * 32f))
    }
}

private fun DrawScope.sceneFry(p: Float) {
    for (i in 0 until 4) {
        val x = -24f + i * 16f
        val fl = 5f * cxWave(p, 5, i * 0.23f)
        flame(x, 42f, 18f + fl, 7f, Accent.a(0.9f))
        flame(x, 42f, 10f + fl * 0.6f, 3.5f, CxGold)
    }
    rotate(-5f * cxWave(p, 2), pivot = Offset(30f, 12f)) {
        for (i in 0 until 4) {
            val q = (p * 2f + i / 4f) % 1f
            val hgt = 4f * q * (1f - q) * 36f
            val x = -20f + i * 13f + 3f * cxWave(q, 1, i * 0.2f)
            val y = 6f - hgt
            val col = when (i % 3) {
                0 -> CxCarrot
                1 -> CxGreen
                else -> CxGold
            }
            rotate(q * 360f, pivot = Offset(x, y)) {
                drawRoundRect(col, Offset(x - 4f, y - 4f), Size(8f, 8f), CornerRadius(2.5f))
            }
        }
        drawRoundRect(CxDark, Offset(-34f, 8f), Size(64f, 12f), CornerRadius(6f))
        drawRoundRect(Color.White.a(0.2f), Offset(-32f, 9f), Size(60f, 2.5f), CornerRadius(2f))
        drawRoundRect(CxDark, Offset(28f, 11f), Size(26f, 5f), CornerRadius(2.5f))
        for (j in 0 until 5) {
            val s = 0.5f + 0.5f * cxWave(p, 6, j * 0.2f)
            drawCircle(Color.White.a(0.5f * s), 1.3f, Offset(-24f + j * 11f, 6f))
        }
    }
}

private fun DrawScope.sceneBake(p: Float) {
    val pulse = 0.75f + 0.25f * cxWave(p, 2)
    drawRoundRect(Color.White.a(0.12f), Offset(-36f, -36f), Size(72f, 72f), CornerRadius(10f))
    drawRoundRect(Color.White.a(0.7f), Offset(-36f, -36f), Size(72f, 72f), CornerRadius(10f), style = Stroke(1.8f))
    val knobs = listOf(-18f, 0f, 18f)
    for ((n, kx) in knobs.withIndex()) {
        drawCircle(Color.White.a(0.8f), 3.4f, Offset(kx, -27f))
        if (n == 1) {
            val ang = p * 2f * PI.toFloat()
            drawLine(Accent, Offset(kx, -27f), Offset(kx + cos(ang) * 3f, -27f + sin(ang) * 3f), 1.2f, StrokeCap.Round)
        }
    }
    drawRoundRect(
        brush = Brush.radialGradient(
            listOf(CxGold.a(0.95f * pulse), Accent.a(0.7f * pulse), Color(0xFF3A0508)),
            center = Offset(0f, 8f), radius = 34f
        ),
        topLeft = Offset(-26f, -14f), size = Size(52f, 38f), cornerRadius = CornerRadius(6f)
    )
    drawRoundRect(CxSteel, Offset(-24f, 17f), Size(48f, 3f), CornerRadius(1.5f))
    val s = 0.65f + 0.35f * (0.5f + 0.5f * cxWave(p, 1, -0.25f))
    val h = 18f * s
    drawArc(
        color = Color(0xFFE0A050), startAngle = 180f, sweepAngle = 180f, useCenter = true,
        topLeft = Offset(-15f, 17f - h), size = Size(30f, 2f * h)
    )
    drawLine(Color.White.a(0.25f), Offset(-18f, -10f), Offset(-6f, 2f), 3f, StrokeCap.Round)
    drawRoundRect(CxSteel, Offset(-18f, 28f), Size(36f, 3f), CornerRadius(1.5f))
}

private fun DrawScope.sceneGrill(p: Float) {
    drawArc(
        color = Color(0xFF3B3030), startAngle = 0f, sweepAngle = 180f, useCenter = true,
        topLeft = Offset(-40f, 4f), size = Size(80f, 40f)
    )
    for (i in 0 until 7) {
        val glow = 0.5f + 0.5f * cxWave(p, 3, i * 0.14f)
        drawCircle(Accent.a(0.45f + 0.5f * glow), 4f, Offset(-30f + i * 10f, 25f))
    }
    for (i in 0 until 5) {
        val fl = 4f * cxWave(p, 4, i * 0.21f)
        flame(-24f + i * 12f, 24f, 16f + fl, 5f, CxCarrot.a(0.9f))
    }
    drawRoundRect(CxSteel, Offset(-40f, -6f), Size(80f, 3f), CornerRadius(1.5f))
    val f = ((p - 0.5f) / 0.4f).coerceIn(0f, 1f)
    val lift = sin(PI.toFloat() * f) * 16f
    val sy = max(0.12f, abs(cos(PI.toFloat() * f)))
    withTransform({ translate(0f, -lift); scale(1f, sy, pivot = Offset(0f, -12f)) }) {
        drawRoundRect(Color(0xFF8E3B2C), Offset(-20f, -18f), Size(40f, 12f), CornerRadius(6f))
        for (i in 0 until 3) {
            drawLine(Color(0xFF4A1A12), Offset(-10f + i * 10f, -16f), Offset(-6f + i * 10f, -8f), 1.6f, StrokeCap.Round)
        }
    }
    for (i in 0 until 6) {
        val q = (p + i / 6f) % 1f
        val x = -12f + (i % 3) * 12f + 2f * cxWave(q, 2, i * 0.1f)
        drawCircle(Color.White.a(0.3f * (1f - q)), 2.5f + q * 4f, Offset(x, -24f - q * 22f))
    }
}

private fun DrawScope.sceneRest(p: Float) {
    drawCircle(Color.White.a(0.12f), 36f, Offset.Zero)
    drawCircle(Color.White.a(0.7f), 36f, Offset.Zero, style = Stroke(2f))
    for (i in 0 until 12) {
        val ang = i * 30f * PI.toFloat() / 180f
        drawLine(
            Color.White.a(0.7f), Offset(cos(ang) * 29f, sin(ang) * 29f), Offset(cos(ang) * 33f, sin(ang) * 33f),
            1.8f, StrokeCap.Round
        )
    }
    drawArc(
        color = Accent, startAngle = -90f, sweepAngle = 360f * p, useCenter = false,
        topLeft = Offset(-30f, -30f), size = Size(60f, 60f), style = Stroke(3.5f, cap = StrokeCap.Round)
    )
    val a = p * 2f * PI.toFloat() - PI.toFloat() / 2f
    drawLine(Color.White, Offset.Zero, Offset(cos(a) * 24f, sin(a) * 24f), 2.4f, StrokeCap.Round)
    val a2 = p * 2f * PI.toFloat() / 12f - PI.toFloat() / 2f
    drawLine(Color.White.a(0.85f), Offset.Zero, Offset(cos(a2) * 15f, sin(a2) * 15f), 3.2f, StrokeCap.Round)
    drawCircle(Accent, 3f, Offset.Zero)
}

private fun DrawScope.scenePeel(p: Float) {
    val body = Path().apply { addOval(Rect(-26f, -12f, 26f, 24f)) }
    drawPath(body, Color(0xFFC59A5C))
    val px = -28f + 56f * p
    clipPath(body) {
        drawRect(Color(0xFFF3DE9E), Offset(-30f, -14f), Size(px + 30f, 40f))
    }
    if (px < 8f) drawCircle(Color(0xFF9B7440), 1.8f, Offset(8f, 6f))
    if (px < -12f) drawCircle(Color(0xFF9B7440), 1.5f, Offset(-12f, 12f))
    for (i in 0 until 3) {
        val q = (p * 3f + i / 3f) % 1f
        withTransform({ translate(px - 6f + q * 10f, -14f + q * 54f); rotate(q * 240f, pivot = Offset.Zero) }) {
            drawRoundRect(Color(0xFFA67C45).a(1f - q), Offset(-8f, -1.5f), Size(16f, 3f), CornerRadius(1.5f))
        }
    }
    withTransform({ translate(px, -14f + 2f * cxWave(p, 8)); rotate(25f, pivot = Offset.Zero) }) {
        drawRoundRect(Accent, Offset(-3f, -30f), Size(6f, 24f), CornerRadius(3f))
        drawRoundRect(CxSteel, Offset(-8f, -6f), Size(16f, 4f), CornerRadius(2f))
    }
}

private fun DrawScope.sceneGrate(p: Float) {
    drawArc(
        color = CxGold, startAngle = 180f, sweepAngle = 180f, useCenter = true,
        topLeft = Offset(-22f, 28f), size = Size(44f, 20f)
    )
    val d = 0.5f + 0.5f * cxWave(p, 2)
    rotate(-10f, pivot = Offset.Zero) {
        drawRoundRect(CxSteel.a(0.85f), Offset(-17f, -40f), Size(34f, 64f), CornerRadius(7f))
        for (r in 0 until 6) {
            for (c in 0 until 3) {
                drawOval(CxDark.a(0.5f), Offset(-10f + c * 9f, -32f + r * 9f), Size(5f, 3f))
            }
        }
        translate(0f, -34f + 40f * d) {
            drawRoundRect(CxGold, Offset(-12f, 0f), Size(24f, 15f), CornerRadius(3f))
            drawRoundRect(Color.White.a(0.3f), Offset(-10f, 2f), Size(20f, 3f), CornerRadius(1.5f))
        }
    }
    for (i in 0 until 6) {
        val q = (p * 2f + i / 6f) % 1f
        val x = -9f + i * 3.6f + 2f * cxWave(q, 2, i * 0.1f)
        val y = 22f + q * 22f
        drawLine(CxGold.a(1f - 0.4f * q), Offset(x, y), Offset(x + 2f, y + 3.5f), 1.7f, StrokeCap.Round)
    }
}

private fun DrawScope.scenePour(p: Float) {
    val th = 100f + 10f * cxWave(p, 1)
    val rad = th * PI.toFloat() / 180f
    val mx = -18f + 28f * sin(rad)
    val my = -22f - 28f * cos(rad)
    val fill = 0.2f + 0.6f * p
    val cx = 16f
    val glass = Path().apply {
        moveTo(cx - 15f, 6f); lineTo(cx + 15f, 6f); lineTo(cx + 11f, 40f); lineTo(cx - 11f, 40f); close()
    }
    drawPath(glass, Color.White.a(0.12f))
    val top = 38f - 30f * fill
    clipPath(glass) { drawRect(CxWater.a(0.75f), Offset(cx - 20f, top), Size(40f, 50f)) }
    drawPath(glass, Color.White.a(0.8f), style = Stroke(1.8f))
    drawLine(CxWater.a(0.9f), Offset(mx, my), Offset(cx - 2f, top), 3.4f, StrokeCap.Round)
    for (i in 0 until 3) {
        val jump = 3f * abs(cxWave(p, 4, i * 0.3f))
        drawCircle(Color.White.a(0.6f), 1.3f, Offset(cx - 6f + i * 6f, top - 1.5f - jump))
    }
    translate(-18f, -22f) {
        rotate(th, pivot = Offset.Zero) {
            drawRoundRect(Accent.a(0.55f), Offset(-11f, -14f), Size(22f, 36f), CornerRadius(6f))
            drawRoundRect(Accent.a(0.55f), Offset(-4f, -28f), Size(8f, 16f), CornerRadius(3f))
            drawRoundRect(Color.White.a(0.85f), Offset(-11f, -14f), Size(22f, 36f), CornerRadius(6f), style = Stroke(1.6f))
            drawRoundRect(Color.White.a(0.85f), Offset(-4f, -28f), Size(8f, 16f), CornerRadius(3f), style = Stroke(1.6f))
            drawRoundRect(Color.White.a(0.8f), Offset(-8f, -2f), Size(16f, 10f), CornerRadius(3f))
        }
    }
}

private fun DrawScope.sceneSeason(p: Float) {
    drawOval(Color.White.a(0.3f), Offset(-36f, 32f), Size(72f, 14f))
    drawOval(Color.White.a(0.7f), Offset(-36f, 32f), Size(72f, 14f), style = Stroke(1.6f))
    drawArc(
        color = Color.White.a(0.9f), startAngle = 180f, sweepAngle = 180f, useCenter = true,
        topLeft = Offset(-10f, 30f), size = Size(20f, 10f)
    )
    for (i in 0 until 10) {
        val q = (p * 2f + i / 10f) % 1f
        val x = ((i % 5) - 2) * 4f + 1.5f * cxWave(q, 2, i * 0.17f)
        drawCircle(Color.White.a(0.95f - 0.4f * q), 1.2f, Offset(x, -5f + q * 35f))
    }
    withTransform({ translate(0f, -26f); rotate(180f + 8f * cxWave(p, 4), pivot = Offset.Zero) }) {
        drawRoundRect(Color.White.a(0.22f), Offset(-9f, -14f), Size(18f, 28f), CornerRadius(6f))
        drawRoundRect(Color.White.a(0.85f), Offset(-9f, -14f), Size(18f, 28f), CornerRadius(6f), style = Stroke(1.6f))
        drawRoundRect(CxSteel, Offset(-10f, -20f), Size(20f, 8f), CornerRadius(4f))
        for (i in -1..1) drawCircle(CxDark, 1f, Offset(i * 5f, -16f))
    }
}

private fun DrawScope.sceneServe(p: Float) {
    drawOval(Color.White.a(0.18f), Offset(-40f, 20f), Size(80f, 22f))
    drawOval(Color.White.a(0.75f), Offset(-40f, 20f), Size(80f, 22f), style = Stroke(1.8f))
    drawOval(Color.White.a(0.25f), Offset(-28f, 24f), Size(56f, 13f), style = Stroke(1.2f))
    drawArc(
        color = Accent.a(0.9f), startAngle = 180f, sweepAngle = 180f, useCenter = true,
        topLeft = Offset(-16f, 12f), size = Size(32f, 22f)
    )
    drawCircle(CxGreen, 2.4f, Offset(-3f, 11f))
    drawCircle(CxGreen, 2.4f, Offset(3f, 12f))
    val lift = 26f * (0.5f + 0.5f * cxWave(p, 1, -0.25f))
    drawArc(
        color = CxSteel.a(0.9f), startAngle = 180f, sweepAngle = 180f, useCenter = true,
        topLeft = Offset(-34f, -14f - lift), size = Size(68f, 72f)
    )
    drawRoundRect(CxSteel, Offset(-36f, 20f - lift), Size(72f, 3f), CornerRadius(1.5f))
    drawCircle(CxGold, 3.5f, Offset(0f, -16f - lift))
    val spots = listOf(Offset(-30f, -6f), Offset(28f, -14f), Offset(-12f, -30f), Offset(18f, -34f))
    for ((i, c) in spots.withIndex()) {
        sparkle(c, 5f * max(0f, cxWave(p, 2, i * 0.25f)), CxGold)
    }
}

private fun DrawScope.sceneGeneric(p: Float) {
    translate(0f, 3f * cxWave(p, 2)) {
        val hat = Color.White.a(0.9f)
        drawCircle(hat, 15f, Offset(-16f, -8f))
        drawCircle(hat, 18f, Offset(0f, -16f))
        drawCircle(hat, 15f, Offset(16f, -8f))
        drawRoundRect(hat, Offset(-24f, -10f), Size(48f, 30f), CornerRadius(6f))
        drawRoundRect(CxSteel, Offset(-24f, 14f), Size(48f, 8f), CornerRadius(3f))
        for (i in -1..1) {
            drawLine(CxSteel.a(0.8f), Offset(i * 10f, -4f), Offset(i * 10f, 12f), 1.4f, StrokeCap.Round)
        }
    }
    val spots = listOf(Offset(-34f, -30f), Offset(34f, -24f), Offset(0f, 36f))
    for ((i, c) in spots.withIndex()) {
        sparkle(c, 5f * max(0f, cxWave(p, 2, i * 0.33f)), CxGold)
    }
}

/**
 * Animación de la acción del paso. Si el paso menciona varias acciones
 * (p. ej. "pica y fríe"), alterna entre ellas cada 3 segundos.
 */
@Composable
fun StepAnimation(step: String, ink: Color) {
    val actions = remember(step) { detectActions(step) }
    var idx by remember(step) { mutableIntStateOf(0) }
    LaunchedEffect(step) {
        idx = 0
        if (actions.size > 1) {
            while (true) {
                delay(3000)
                idx = (idx + 1) % actions.size
            }
        }
    }
    val action = actions.getOrNull(idx)
    val t = rememberInfiniteTransition(label = "scene")
    val phase = t.animateFloat(0f, 1f, infiniteRepeatable(tween(2400, easing = LinearEasing), RepeatMode.Restart), label = "p")
    GlassCard(Modifier.fillMaxWidth()) {
        AnimatedContent(
            targetState = action,
            transitionSpec = { (fadeIn(tween(350)) + scaleIn(tween(350), initialScale = 0.85f)) togetherWith fadeOut(tween(200)) },
            label = "sceneSwap"
        ) { a ->
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Canvas(Modifier.fillMaxWidth().height(190.dp)) {
                    val u = size.minDimension / 100f
                    withTransform({
                        translate(size.width / 2f, size.height / 2f)
                        scale(u, u, pivot = Offset.Zero)
                    }) {
                        val p = phase.value
                        when (a) {
                            CookAction.CUT -> sceneCut(p)
                            CookAction.BLEND -> sceneBlend(p)
                            CookAction.WHISK -> sceneWhisk(p)
                            CookAction.KNEAD -> sceneKnead(p)
                            CookAction.BOIL -> sceneBoil(p)
                            CookAction.FRY -> sceneFry(p)
                            CookAction.BAKE -> sceneBake(p)
                            CookAction.GRILL -> sceneGrill(p)
                            CookAction.REST -> sceneRest(p)
                            CookAction.PEEL -> scenePeel(p)
                            CookAction.GRATE -> sceneGrate(p)
                            CookAction.POUR -> scenePour(p)
                            CookAction.SEASON -> sceneSeason(p)
                            CookAction.SERVE -> sceneServe(p)
                            null -> sceneGeneric(p)
                        }
                    }
                }
                Text(
                    a?.label ?: "Preparando",
                    color = Accent, fontWeight = FontWeight.Bold, fontSize = 18.sp, textAlign = TextAlign.Center
                )
            }
        }
    }
}

// =====================================================================
//  IMAGEN DE CADA INGREDIENTE (icono en cristal, funciona sin internet)
// =====================================================================

private val FOOD_DEFS: List<Pair<String, List<String>>> = listOf(
    "🥥" to listOf("leche de coco", "coco"),
    "🍅" to listOf("pasta de tomate", "tomate", "jitomate"),
    "🧀" to listOf("queso crema", "queso", "parmesano", "mozzarella", "mozarella", "cheddar", "ricotta", "feta", "requeson"),
    "🥛" to listOf("leche", "crema de leche", "crema", "nata", "yogur", "yogurt", "kefir"),
    "🧈" to listOf("mantequilla", "margarina", "manteca"),
    "🥚" to listOf("huevo", "clara", "yema"),
    "🌾" to listOf("harina", "trigo", "avena", "maicena", "almidon", "salvado", "centeno"),
    "🍬" to listOf("azucar", "panela", "piloncillo", "jarabe", "sirope", "glucosa", "edulcorante", "caramelo"),
    "🧂" to listOf("sal", "pimienta", "canela", "comino", "paprika", "pimenton", "curcuma", "especia", "vainilla", "levadura", "bicarbonato", "polvo de hornear", "nuez moscada", "clavo"),
    "🫑" to listOf("pimiento", "morron"),
    "🌶️" to listOf("chile", "aji", "jalapeno", "guindilla", "cayena", "picante"),
    "🧅" to listOf("cebolla", "cebollin", "chalota", "cebolleta", "puerro"),
    "🧄" to listOf("ajo"),
    "🥔" to listOf("papa", "patata"),
    "🍠" to listOf("camote", "batata", "boniato"),
    "🥕" to listOf("zanahoria"),
    "🌽" to listOf("maiz", "elote", "choclo"),
    "🥦" to listOf("brocoli", "coliflor"),
    "🥬" to listOf("lechuga", "espinaca", "acelga", "col", "repollo", "rucula", "berro", "kale"),
    "🥒" to listOf("pepino", "calabacin", "pepinillo"),
    "🍆" to listOf("berenjena"),
    "🎃" to listOf("calabaza", "zapallo", "auyama"),
    "🍄" to listOf("champinon", "hongo", "seta", "portobello"),
    "🥑" to listOf("aguacate", "palta"),
    "🌿" to listOf("perejil", "cilantro", "albahaca", "menta", "romero", "tomillo", "oregano", "laurel", "hierbabuena", "eneldo", "cebollino", "hierba", "salvia"),
    "🍋" to listOf("limon", "lima"),
    "🍊" to listOf("naranja", "mandarina", "toronja", "pomelo"),
    "🍎" to listOf("manzana"),
    "🍐" to listOf("pera"),
    "🍌" to listOf("platano", "banana", "banano", "guineo"),
    "🍓" to listOf("fresa", "frutilla"),
    "🍇" to listOf("uva", "pasas", "arandano", "mora", "frambuesa", "zarzamora"),
    "🍒" to listOf("cereza", "guinda"),
    "🍑" to listOf("durazno", "melocoton", "albaricoque", "damasco"),
    "🍍" to listOf("pina", "ananas"),
    "🥭" to listOf("mango"),
    "🍉" to listOf("sandia"),
    "🍈" to listOf("melon"),
    "🥝" to listOf("kiwi"),
    "🫒" to listOf("aceite de oliva", "aceite", "aceituna", "oliva"),
    "🌰" to listOf("frijol", "judia", "alubia", "habichuela", "lenteja", "garbanzo", "poroto", "haba"),
    "🥜" to listOf("mani", "cacahuate", "nuez", "nueces", "almendra", "avellana", "pistacho", "castana", "semilla", "ajonjoli", "sesamo"),
    "🍚" to listOf("arroz"),
    "🍝" to listOf("pasta", "espagueti", "spaghetti", "fideo", "macarron", "tallarin", "lasana", "penne"),
    "🍞" to listOf("pan rallado", "pan", "baguette", "tostada", "migas", "bizcocho"),
    "🥐" to listOf("hojaldre", "croissant"),
    "🌮" to listOf("tortilla", "taco"),
    "🍗" to listOf("pollo", "pechuga", "muslo", "gallina", "pavo"),
    "🥩" to listOf("carne", "res", "ternera", "cerdo", "chuleta", "bistec", "filete", "costilla", "cordero", "molida"),
    "🥓" to listOf("tocino", "bacon", "panceta", "jamon", "salchicha", "chorizo", "embutido"),
    "🐟" to listOf("pescado", "salmon", "atun", "bacalao", "merluza", "tilapia", "sardina", "trucha"),
    "🦐" to listOf("camaron", "gamba", "langostino", "marisco", "langosta", "cangrejo", "calamar", "pulpo", "mejillon", "almeja"),
    "🍯" to listOf("miel"),
    "🍫" to listOf("chocolate", "cacao", "cocoa"),
    "☕" to listOf("cafe", "espresso"),
    "🍵" to listOf("manzanilla", "matcha"),
    "🍷" to listOf("vino", "cerveza", "ron", "licor", "brandy", "tequila", "whisky"),
    "🍲" to listOf("caldo", "sopa", "consome", "bouillon"),
    "🥫" to listOf("salsa", "ketchup", "catsup", "mayonesa", "mostaza", "soya", "soja", "vinagre", "atun enlatado", "lata"),
    "💧" to listOf("agua"),
    "🧊" to listOf("hielo"),
    "🍨" to listOf("helado"),
    "🍪" to listOf("galleta", "galletas"),
    "🍶" to listOf("sake", "mirin")
)

private val FOOD_RULES: List<Triple<Regex, String, Int>> by lazy {
    FOOD_DEFS.flatMap { (emoji, keys) ->
        keys.map { k ->
            Triple(Regex("\\b" + Regex.escape(normText(k)) + "(?:s|es)?\\b"), emoji, k.length)
        }
    }
}

/** Icono del ingrediente: gana la palabra que aparece primero; a igualdad, la frase más larga. */
fun ingredientEmoji(text: String, fallback: String = "🍽️"): String {
    val t = normText(text)
    var best: String? = null
    var bestPos = Int.MAX_VALUE
    var bestLen = 0
    for ((re, emoji, len) in FOOD_RULES) {
        val m = re.find(t) ?: continue
        val pos = m.range.first
        if (pos < bestPos || (pos == bestPos && len > bestLen)) {
            best = emoji; bestPos = pos; bestLen = len
        }
    }
    return best ?: fallback
}

/** Icono de respaldo para la lista de compras según su categoría. */
fun categoryEmoji(cat: String): String {
    val c = normText(cat)
    return when {
        c.contains("fruta") -> "🍎"
        c.contains("verdura") || c.contains("vegetal") || c.contains("hortaliza") -> "🥦"
        c.contains("carne") || c.contains("pollo") -> "🥩"
        c.contains("pescad") || c.contains("marisc") -> "🐟"
        c.contains("lacteo") || c.contains("leche") -> "🥛"
        c.contains("panad") || c.contains("pan") -> "🍞"
        c.contains("bebida") -> "🥤"
        c.contains("limpieza") -> "🧴"
        c.contains("congelad") -> "🧊"
        c.contains("despensa") || c.contains("abarrote") || c.contains("enlatad") -> "🥫"
        c.contains("snack") || c.contains("dulce") -> "🍪"
        c.contains("condiment") || c.contains("especia") -> "🧂"
        else -> "🛒"
    }
}

/** Burbuja liquid glass con el icono del alimento. */
@Composable
fun FoodBadge(emoji: String, size: Dp = 40.dp, checked: Boolean = false) {
    val sc by animateFloatAsState(if (checked) 0.85f else 1f, spring(dampingRatio = 0.4f, stiffness = 400f), label = "foodScale")
    Box(Modifier.graphicsLayer { scaleX = sc; scaleY = sc; alpha = if (checked) 0.5f else 1f }) {
        IconBubble(emoji, size)
    }
}

/** Fila de ingrediente con su imagen; aparece con un pequeño retraso escalonado. */
@Composable
fun IngredientRow(index: Int, line: String, ink: Color) {
    val emoji = remember(line) { ingredientEmoji(line) }
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { delay(index * 45L); shown = true }
    val a by animateFloatAsState(if (shown) 1f else 0f, tween(300), label = "ingAlpha")
    Row(
        Modifier.fillMaxWidth().padding(vertical = 4.dp).graphicsLayer { alpha = a; translationX = (1f - a) * 40f },
        verticalAlignment = Alignment.CenterVertically
    ) {
        FoodBadge(emoji, 40.dp)
        Spacer(Modifier.width(12.dp))
        Text(line, color = ink, fontSize = 16.sp)
    }
}

/** Vista previa de las imágenes mientras se escriben los ingredientes. */
@Composable
fun IngredientPreview(text: String, ink: Color) {
    val lines = text.lines().map { it.trim() }.filter { it.isNotEmpty() }
    if (lines.isEmpty()) return
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        lines.forEach { l ->
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(62.dp)) {
                FoodBadge(ingredientEmoji(l), 44.dp)
                Text(l, color = ink.copy(alpha = 0.7f), fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}
