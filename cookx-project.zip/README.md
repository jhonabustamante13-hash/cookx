# CookX — Liquid Glass Red

App Android nativa (Kotlin + Jetpack Compose + Room), id `com.cookx.app`.

## Qué incluye esta versión (0.4.0)
- Fondo negro con resplandor rojo animado, cristales rojos, barra inferior con indicador animado.
- Recetas en Room (se conservan al reiniciar): crear, editar, eliminar, favoritas, etiquetas, notas, foto de la galería, búsqueda, 25 categorías, porciones ajustables.
- Modo cocina: un paso a la vez, pantalla encendida, progreso animado, pasos completados y **animación por acción** (picar, triturar, batir, amasar, hervir, freír, hornear, asar, reposar, pelar, rallar, verter, sazonar, servir). Si un paso menciona varias acciones, alterna entre ellas.
- Iconos liquid glass vectoriales (los mismos del index.html): ingredientes (recetas, vista previa al escribir y lista de Compras) y pestañas de la barra inferior, en burbujas de cristal con brillo y reflejo. Código en `Icons.kt`.
- Plan: vista diaria de 7 días, 4 comidas, repetir día, historial, resumen y presupuesto estimado.
- Compras: varias listas, categorías, marcar comprados, añadir desde receta, compartir.
- Útiles: conversores reales, porciones, equivalencias, temperaturas, sustituciones, temporizadores con notificación.
- Datos: recetas, favoritas, preparaciones, tiempo y gráficas calculadas de tus datos.

## Pendiente (no implementado todavía)
Biblioteca inicial de 30–50 recetas con fotos y licencias verificadas, vista mensual del plan, editar productos de compras, actividad semanal/mensual, temporizadores dentro del modo cocina.

## Compilar
Sube `cookx-project.zip` al repositorio: GitHub Actions lo descomprime y genera el APK (artefacto `CookX-APK`).
